<?php
$formJob = isset($job) && is_array($job) ? $job : array();
$oldJobInput = isset($_SESSION['job_old_input']) ? $_SESSION['job_old_input'] : array();
unset($_SESSION['job_old_input']);
$formJob = array_merge($formJob, $oldJobInput);
$formAction = isset($formJob['id']) ? 'update' : 'create';
?>
<form class="job-form profile-edit-form" action="actions/job.php" method="post">
    <input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>">
    <input type="hidden" name="action" value="<?php echo $formAction; ?>">
    <?php if ($formAction === 'update') : ?><input type="hidden" name="job_id" value="<?php echo (int) $formJob['id']; ?>"><?php endif; ?>
    <section class="dashboard-panel"><p class="panel-eyebrow">Opportunity details</p><h2>Describe the role</h2>
        <div class="form-field"><label for="title">Job title</label><input id="title" name="title" type="text" maxlength="200" required value="<?php echo escape_html(isset($formJob['title']) ? $formJob['title'] : ''); ?>"></div>
        <div class="form-row"><div class="form-field"><label for="company">Company</label><input id="company" name="company" type="text" maxlength="150" required value="<?php echo escape_html(isset($formJob['company']) ? $formJob['company'] : ''); ?>"></div><div class="form-field"><label for="location">Location</label><input id="location" name="location" type="text" maxlength="150" required value="<?php echo escape_html(isset($formJob['location']) ? $formJob['location'] : ''); ?>"></div></div>
        <div class="form-row"><div class="form-field"><label for="job_type">Job type</label><input id="job_type" name="job_type" type="text" maxlength="50" placeholder="Full-time, Internship..." required value="<?php echo escape_html(isset($formJob['job_type']) ? $formJob['job_type'] : ''); ?>"></div><div class="form-field"><label for="experience">Experience</label><input id="experience" name="experience" type="text" maxlength="100" placeholder="Entry level, 2+ years..." required value="<?php echo escape_html(isset($formJob['experience']) ? $formJob['experience'] : ''); ?>"></div></div>
        <div class="form-field"><label for="salary">Salary</label><input id="salary" name="salary" type="text" maxlength="100" required value="<?php echo escape_html(isset($formJob['salary']) ? $formJob['salary'] : ''); ?>"></div>
        <div class="form-field"><label for="description">Description</label><textarea id="description" name="description" maxlength="5000" rows="7" required><?php echo escape_html(isset($formJob['description']) ? $formJob['description'] : ''); ?></textarea></div>
        <div class="form-field"><label for="skills">Required skills</label><textarea id="skills" name="skills" maxlength="2000" rows="4" required><?php echo escape_html(isset($formJob['skills']) ? $formJob['skills'] : ''); ?></textarea></div>
        <div class="form-field"><label for="apply_link">External application link <small>(HTTP or HTTPS only)</small></label><input id="apply_link" name="apply_link" type="url" maxlength="500" required placeholder="https://example.com/apply" value="<?php echo escape_html(isset($formJob['apply_link']) ? $formJob['apply_link'] : ''); ?>"></div>
    </section>
    <div class="profile-form-actions"><a class="button button-secondary" href="jobs.php">Cancel</a><button class="button button-primary" type="submit"><?php echo $formAction === 'update' ? 'Save changes' : 'Post job'; ?> <span aria-hidden="true">→</span></button></div>
</form>
