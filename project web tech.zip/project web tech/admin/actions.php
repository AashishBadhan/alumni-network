<?php
require_once __DIR__ . '/access.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}
if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    admin_redirect_with_message('', array('Your form session expired. Please try again.'));
}
$action = isset($_POST['action']) ? $_POST['action'] : '';
$userId = filter_var(isset($_POST['user_id']) ? $_POST['user_id'] : null, FILTER_VALIDATE_INT);
$jobId = filter_var(isset($_POST['job_id']) ? $_POST['job_id'] : null, FILTER_VALIDATE_INT);
$eventId = filter_var(isset($_POST['event_id']) ? $_POST['event_id'] : null, FILTER_VALIDATE_INT);
$registrationId = filter_var(isset($_POST['registration_id']) ? $_POST['registration_id'] : null, FILTER_VALIDATE_INT);
$errors = array();
try {
    if (in_array($action, array('block_user', 'unblock_user', 'delete_user', 'update_user'), true)) {
        if ($userId === false || $userId < 1) {
            $errors[] = 'The user could not be identified.';
        }
        $targetStatement = null;
        $targetUser = false;
        if (empty($errors)) {
            $targetStatement = $pdo->prepare('SELECT id, role, status FROM users WHERE id = :id LIMIT 1');
            $targetStatement->execute(array(':id' => $userId));
            $targetUser = $targetStatement->fetch();
            if ($targetUser === false) {
                $errors[] = 'The user could not be found.';
            }
        }
        if (empty($errors) && in_array($action, array('block_user', 'unblock_user'), true)
            && !can_change_admin_status($adminUser, $targetUser, $action === 'block_user' ? 'blocked' : 'active')) {
            $errors[] = 'You do not have permission to change this account status.';
        }
        if (empty($errors) && $action === 'delete_user'
            && !can_delete_admin_user($adminUser, $targetUser)) {
            $errors[] = 'You do not have permission to delete this account.';
        }
        if (empty($errors) && $action === 'block_user') {
            $statement = $pdo->prepare("UPDATE users SET status='blocked' WHERE id=:id");
            $statement->execute(array(':id' => $userId));
            if ($statement->rowCount() !== 1) { $errors[] = 'The user could not be blocked.'; } else { admin_redirect_with_message('User blocked successfully.'); }
        }
        if (empty($errors) && $action === 'unblock_user') {
            $statement = $pdo->prepare("UPDATE users SET status='active' WHERE id=:id");
            $statement->execute(array(':id' => $userId));
            if ($statement->rowCount() !== 1) { $errors[] = 'The user could not be unblocked.'; } else { admin_redirect_with_message('User unblocked successfully.'); }
        }
        if (empty($errors) && $action === 'delete_user') {
            $statement = $pdo->prepare('DELETE FROM users WHERE id=:id');
            $statement->execute(array(':id' => $userId));
            if ($statement->rowCount() !== 1) { $errors[] = 'The user could not be deleted.'; } else { admin_redirect_with_message('User deleted successfully.'); }
        }
        if (empty($errors) && $action === 'update_user') {
            $name = trim(isset($_POST['name']) ? $_POST['name'] : ''); $email = trim(isset($_POST['email']) ? $_POST['email'] : ''); $role = isset($_POST['role']) ? $_POST['role'] : ''; $status = isset($_POST['status']) ? $_POST['status'] : ''; $department = trim(isset($_POST['department']) ? $_POST['department'] : ''); $year = trim(isset($_POST['graduation_year']) ? $_POST['graduation_year'] : ''); $company = trim(isset($_POST['company']) ? $_POST['company'] : ''); $designation = trim(isset($_POST['designation']) ? $_POST['designation'] : '');
            if ($name === '' || strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
                $errors[] = 'Please enter a valid name and email.';
            }
            if (!in_array($role, array('student', 'alumni', 'admin'), true) || !in_array($status, array('active', 'blocked'), true)) {
                $errors[] = 'The role or status is invalid.';
            }
            if ($year !== '' && (!ctype_digit($year) || (int) $year < 1901 || (int) $year > (int) date('Y') + 10)) {
                $errors[] = 'The graduation year is invalid.';
            }
            if (empty($errors) && $role !== $targetUser['role']
                && !can_change_admin_role($adminUser, $targetUser, $role)) {
                $errors[] = 'You do not have permission to change this account role.';
            }
            if (empty($errors) && $status !== $targetUser['status']
                && !can_change_admin_status($adminUser, $targetUser, $status)) {
                $errors[] = 'You do not have permission to change this account status.';
            }
            if (empty($errors)) {
                $pdo->beginTransaction();
                $statement = $pdo->prepare('UPDATE users SET name=:name,email=:email,role=:role,status=:status WHERE id=:id');
                $statement->execute(array(':name' => $name, ':email' => $email, ':role' => $role, ':status' => $status, ':id' => $userId));
                $profile = $pdo->prepare('INSERT INTO profiles (user_id,department,graduation_year,company,designation) VALUES (:id,:department,:year,:company,:designation) ON DUPLICATE KEY UPDATE department=VALUES(department),graduation_year=VALUES(graduation_year),company=VALUES(company),designation=VALUES(designation)');
                $profile->execute(array(':id' => $userId, ':department' => $department !== '' ? $department : null, ':year' => $year !== '' ? $year : null, ':company' => $company !== '' ? $company : null, ':designation' => $designation !== '' ? $designation : null));
                $pdo->commit();
                if ((int) $userId === (int) $adminUser['id']) {
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_role'] = $role;
                }
                admin_redirect_with_message('User updated successfully.');
            }
        }
    } elseif ($action === 'delete_job' && $jobId > 0) { $statement = $pdo->prepare('DELETE FROM jobs WHERE id=:id'); $statement->execute(array(':id'=>$jobId)); if ($statement->rowCount() === 1) { admin_redirect_with_message('Job deleted successfully.'); } $errors[]='The job could not be deleted.'; }
    elseif ($action === 'delete_event' && $eventId > 0) { $statement = $pdo->prepare('DELETE FROM events WHERE id=:id'); $statement->execute(array(':id'=>$eventId)); if ($statement->rowCount() === 1) { admin_redirect_with_message('Event deleted successfully.'); } $errors[]='The event could not be deleted.'; }
    elseif ($action === 'delete_registration' && $registrationId > 0) { $statement = $pdo->prepare('DELETE FROM event_registrations WHERE id=:id'); $statement->execute(array(':id'=>$registrationId)); if ($statement->rowCount() === 1) { admin_redirect_with_message('Registration removed successfully.'); } $errors[]='The registration could not be removed.'; }
    else { $errors[] = 'The requested admin action is invalid.'; }
} catch (PDOException $exception) { if ($pdo->inTransaction()) { $pdo->rollBack(); } error_log('AlumniConnect admin action failed. PDO error code: ' . $exception->getCode()); $errors[] = 'The admin action could not be completed.'; }
admin_redirect_with_message('', $errors);
