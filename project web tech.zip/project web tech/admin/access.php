<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/admin_permissions.php';

start_secure_session();
$assetPrefix = '../';
$sitePrefix = '../';

if (!is_user_logged_in()) {
    header('Location: ../login.php');
    exit;
}

$adminUser = get_current_user_info();
if ($adminUser === null || $adminUser['role'] !== 'admin') {
    http_response_code(403);
    exit('You do not have permission to access the admin panel.');
}

$adminAccountStatement = $pdo->prepare('SELECT role, status FROM users WHERE id = :user_id LIMIT 1');
$adminAccountStatement->execute(array(':user_id' => $adminUser['id']));
$adminAccount = $adminAccountStatement->fetch();
if ($adminAccount === false || $adminAccount['status'] !== 'active' || $adminAccount['role'] !== 'admin') {
    $_SESSION = array();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

function admin_escape($value)
{
    return escape_html($value);
}

function admin_redirect_with_message($message, $errors = array())
{
    if ($message !== '') {
        $_SESSION['admin_success'] = $message;
    }
    if (!empty($errors)) {
        $_SESSION['admin_errors'] = $errors;
    }
    $allowedPages = array('dashboard.php', 'users.php', 'edit-user.php', 'jobs.php', 'events.php', 'registrations.php');
    $returnPage = isset($_POST['return_to']) ? basename($_POST['return_to']) : 'dashboard.php';
    if (!in_array($returnPage, $allowedPages, true)) {
        $returnPage = 'dashboard.php';
    }
    header('Location: ' . $returnPage);
    exit;
}
