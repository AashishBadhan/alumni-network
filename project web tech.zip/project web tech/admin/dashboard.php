<?php
require_once __DIR__ . '/access.php';
$pageHeading = 'Admin dashboard';
$pageTitle = 'Admin Dashboard | AlumniConnect';
$pageDescription = 'Manage the AlumniConnect community.';
$bodyClass = 'dashboard-page';
$data = array('users' => 0, 'students' => 0, 'alumni' => 0, 'active' => 0, 'blocked' => 0, 'jobs' => 0, 'events' => 0, 'upcoming' => 0, 'recent_users' => array(), 'recent_jobs' => array(), 'recent_events' => array());
try {
    $stats = $pdo->query(
        "SELECT
            (SELECT COUNT(*) FROM users) AS users,
            (SELECT COUNT(*) FROM users WHERE role = 'student') AS students,
            (SELECT COUNT(*) FROM users WHERE role = 'alumni') AS alumni,
            (SELECT COUNT(*) FROM users WHERE status = 'active') AS active,
            (SELECT COUNT(*) FROM users WHERE status = 'blocked') AS blocked,
            (SELECT COUNT(*) FROM jobs) AS jobs,
            (SELECT COUNT(*) FROM events) AS events,
            (SELECT COUNT(*) FROM events WHERE event_date >= NOW()) AS upcoming"
    )->fetch();
    if ($stats !== false) {
        foreach ($data as $key => $value) {
            if (isset($stats[$key])) {
                $data[$key] = (int) $stats[$key];
            }
        }
    }
    $data['recent_users'] = $pdo->query("SELECT id, name, email, role, status, created_at FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();
    $data['recent_jobs'] = $pdo->query("SELECT j.id, j.title, j.company, u.name AS creator_name FROM jobs j INNER JOIN users u ON u.id=j.user_id ORDER BY j.created_at DESC LIMIT 5")->fetchAll();
    $data['recent_events'] = $pdo->query("SELECT e.id, e.title, e.event_date, u.name AS creator_name FROM events e INNER JOIN users u ON u.id=e.user_id ORDER BY e.event_date DESC LIMIT 5")->fetchAll();
} catch (PDOException $exception) {
    error_log('AlumniConnect admin dashboard query failed. PDO error code: ' . $exception->getCode());
    $_SESSION['admin_errors'] = array('Some dashboard information is temporarily unavailable.');
}
require_once __DIR__ . '/../includes/header.php';
require __DIR__ . '/layout.php';
?>
<section class="directory-heading"><div><p class="eyebrow">Administration</p><h1>Community overview</h1><p>Monitor members, opportunities and events from one place.</p></div></section>
<section class="dashboard-stats admin-stats"><article class="dashboard-stat-card"><span class="stat-icon stat-icon-blue">◎</span><div><strong><?php echo $data['users']; ?></strong><span>Total users</span></div></article><article class="dashboard-stat-card"><span class="stat-icon stat-icon-purple">♧</span><div><strong><?php echo $data['students']; ?></strong><span>Students</span></div></article><article class="dashboard-stat-card"><span class="stat-icon stat-icon-purple">♧</span><div><strong><?php echo $data['alumni']; ?></strong><span>Alumni</span></div></article><article class="dashboard-stat-card"><span class="stat-icon stat-icon-green">✓</span><div><strong><?php echo $data['active']; ?></strong><span>Active accounts</span></div></article><article class="dashboard-stat-card"><span class="stat-icon stat-icon-gold">!</span><div><strong><?php echo $data['blocked']; ?></strong><span>Blocked accounts</span></div></article><article class="dashboard-stat-card"><span class="stat-icon stat-icon-gold">▣</span><div><strong><?php echo $data['jobs']; ?></strong><span>Total jobs</span></div></article><article class="dashboard-stat-card"><span class="stat-icon stat-icon-green">◆</span><div><strong><?php echo $data['events']; ?></strong><span>Total events</span></div></article><article class="dashboard-stat-card"><span class="stat-icon stat-icon-blue">◷</span><div><strong><?php echo $data['upcoming']; ?></strong><span>Upcoming events</span></div></article></section>
<div class="admin-grid-three"><section class="dashboard-panel"><div class="panel-heading"><div><p class="panel-eyebrow">Latest members</p><h2>Recent users</h2></div><a class="panel-link" href="users.php">Manage →</a></div><?php if (empty($data['recent_users'])) : ?><p class="empty-state">No users yet.</p><?php else : ?><div class="compact-list"><?php foreach ($data['recent_users'] as $user) : ?><div class="compact-row"><span class="member-avatar"><?php echo admin_escape(strtoupper(substr($user['name'], 0, 1))); ?></span><span><strong><?php echo admin_escape($user['name']); ?></strong><small><?php echo admin_escape(ucfirst($user['role'])); ?> · <?php echo admin_escape(date('M j, Y', strtotime($user['created_at']))); ?></small></span></div><?php endforeach; ?></div><?php endif; ?></section><section class="dashboard-panel"><div class="panel-heading"><div><p class="panel-eyebrow">Career board</p><h2>Recent jobs</h2></div><a class="panel-link" href="jobs.php">Manage →</a></div><?php if (empty($data['recent_jobs'])) : ?><p class="empty-state">No jobs yet.</p><?php else : ?><div class="compact-list"><?php foreach ($data['recent_jobs'] as $job) : ?><div class="compact-row"><span class="compact-icon stat-icon stat-icon-gold">▣</span><span><strong><?php echo admin_escape($job['title']); ?></strong><small><?php echo admin_escape($job['company']); ?> · <?php echo admin_escape($job['creator_name']); ?></small></span></div><?php endforeach; ?></div><?php endif; ?></section><section class="dashboard-panel"><div class="panel-heading"><div><p class="panel-eyebrow">Community calendar</p><h2>Recent events</h2></div><a class="panel-link" href="events.php">Manage →</a></div><?php if (empty($data['recent_events'])) : ?><p class="empty-state">No events yet.</p><?php else : ?><div class="compact-list"><?php foreach ($data['recent_events'] as $event) : ?><div class="compact-row"><span class="compact-icon stat-icon stat-icon-green">◆</span><span><strong><?php echo admin_escape($event['title']); ?></strong><small><?php echo admin_escape($event['creator_name']); ?> · <?php echo admin_escape(date('M j, Y', strtotime($event['event_date']))); ?></small></span></div><?php endforeach; ?></div><?php endif; ?></section></div>
<?php require __DIR__ . '/footer.php'; ?>