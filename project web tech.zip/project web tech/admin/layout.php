<?php
$adminPage = basename($_SERVER['PHP_SELF']);
?>
<div class="dashboard-layout">
    <aside class="dashboard-sidebar" id="dashboard-sidebar" aria-label="Admin navigation">
        <a class="sidebar-brand" href="dashboard.php"><span class="brand-mark">A</span><span class="brand-name">Alumni<span>Connect</span></span></a>
        <nav class="sidebar-navigation">
            <a class="<?php echo $adminPage === 'dashboard.php' ? 'is-active' : ''; ?>" href="dashboard.php"><span class="sidebar-icon">▦</span>Overview</a>
            <a class="<?php echo in_array($adminPage, array('users.php', 'edit-user.php'), true) ? 'is-active' : ''; ?>" href="users.php"><span class="sidebar-icon">◎</span>Users</a>
            <a class="<?php echo $adminPage === 'jobs.php' ? 'is-active' : ''; ?>" href="jobs.php"><span class="sidebar-icon">▣</span>Jobs</a>
            <a class="<?php echo $adminPage === 'events.php' ? 'is-active' : ''; ?>" href="events.php"><span class="sidebar-icon">◆</span>Events</a>
            <a class="<?php echo $adminPage === 'registrations.php' ? 'is-active' : ''; ?>" href="registrations.php"><span class="sidebar-icon">✓</span>Registrations</a>
            <a href="../dashboard.php"><span class="sidebar-icon">←</span>Member dashboard</a>
        </nav>
        <a class="sidebar-logout" href="../logout.php"><span class="sidebar-icon">↪</span>Sign out</a>
    </aside>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle admin menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button>
            <div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect administration</span><strong><?php echo admin_escape($pageHeading); ?></strong></div>
            <a class="dashboard-account" href="../profile.php"><span class="dashboard-avatar"><?php echo admin_escape(strtoupper(substr($adminUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo admin_escape($adminUser['name']); ?></strong><small>Administrator</small></span></a>
        </header>
        <main class="dashboard-main admin-main">
            <?php if (!empty($_SESSION['admin_success'])) : ?><div class="form-alert form-alert-success" role="status"><?php echo admin_escape($_SESSION['admin_success']); ?></div><?php unset($_SESSION['admin_success']); endif; ?>
            <?php if (!empty($_SESSION['admin_errors'])) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($_SESSION['admin_errors'] as $error) : ?><li><?php echo admin_escape($error); ?></li><?php endforeach; ?></ul></div><?php unset($_SESSION['admin_errors']); endif; ?>
