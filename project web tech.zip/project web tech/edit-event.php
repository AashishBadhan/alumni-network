<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';
$currentUser = get_current_user_info();
$eventId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$event = false;
if ($eventId !== false && $eventId > 0) {
    $statement = $pdo->prepare('SELECT e.*, u.status AS creator_status FROM events e INNER JOIN users u ON u.id = e.user_id WHERE e.id = :event_id LIMIT 1');
    $statement->execute(array(':event_id' => $eventId));
    $event = $statement->fetch();
}
if ($event === false || $event['creator_status'] !== 'active' || ((int) $event['user_id'] !== (int) $currentUser['id'] && $currentUser['role'] !== 'admin')) {
    http_response_code(403);
    exit('You do not have permission to edit this event.');
}
$pageTitle = 'Edit Event | AlumniConnect';
$pageDescription = 'Edit your AlumniConnect event.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar"><button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button><div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Edit event</strong></div><a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a></header>
        <main class="dashboard-main event-form-main"><a class="back-link" href="events.php?view=<?php echo (int) $event['id']; ?>">← Back to event</a><section class="directory-heading"><div><p class="eyebrow">Keep your community informed</p><h1>Edit event</h1><p>Update the details attendees need to know.</p></div></section><?php if (!empty($_SESSION['event_errors'])) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($_SESSION['event_errors'] as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php unset($_SESSION['event_errors']); endif; ?><?php require __DIR__ . '/event-form.php'; ?></main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>