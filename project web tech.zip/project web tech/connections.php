<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$connections = array();
$receivedRequests = array();
$sentRequests = array();

try {
    $accountStatement = $pdo->prepare('SELECT status FROM users WHERE id = :user_id LIMIT 1');
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: login.php');
        exit;
    }

    $connectionStatement = $pdo->prepare(
        "SELECT c.id, u.id AS member_id, u.name, u.role,
                p.department, p.graduation_year, p.company, p.designation,
                p.city, p.profile_image
         FROM connections c
         INNER JOIN users u ON u.id = CASE
             WHEN c.sender_id = :sender_id THEN c.receiver_id
             ELSE c.sender_id
         END
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE (c.sender_id = :sender_id_check OR c.receiver_id = :receiver_id_check)
           AND c.status = 'accepted' AND u.status = 'active'
         ORDER BY c.updated_at DESC"
    );
    $connectionStatement->execute(array(
        ':sender_id' => $currentUser['id'],
        ':sender_id_check' => $currentUser['id'],
        ':receiver_id_check' => $currentUser['id'],
    ));
    $connections = $connectionStatement->fetchAll();

    $receivedStatement = $pdo->prepare(
        "SELECT c.id, u.id AS member_id, u.name, u.role,
                p.department, p.graduation_year, p.company, p.designation,
                p.city, p.profile_image
         FROM connections c
         INNER JOIN users u ON u.id = c.sender_id
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE c.receiver_id = :user_id AND c.status = 'pending'
           AND u.status = 'active'
         ORDER BY c.created_at DESC"
    );
    $receivedStatement->execute(array(':user_id' => $currentUser['id']));
    $receivedRequests = $receivedStatement->fetchAll();

    $sentStatement = $pdo->prepare(
        "SELECT c.id, u.id AS member_id, u.name, u.role,
                p.department, p.graduation_year, p.company, p.designation,
                p.city, p.profile_image
         FROM connections c
         INNER JOIN users u ON u.id = c.receiver_id
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE c.sender_id = :user_id AND c.status = 'pending'
           AND u.status = 'active'
         ORDER BY c.created_at DESC"
    );
    $sentStatement->execute(array(':user_id' => $currentUser['id']));
    $sentRequests = $sentStatement->fetchAll();
} catch (PDOException $exception) {
    error_log('AlumniConnect connections query failed. PDO error code: ' . $exception->getCode());
    $_SESSION['connection_errors'] = array('Connections are temporarily unavailable. Please try again later.');
}

$pageTitle = 'Connections | AlumniConnect';
$pageDescription = 'Manage your AlumniConnect connection requests and community relationships.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false">
                <span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span>
            </button>
            <div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Connections</strong></div>
            <a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a>
        </header>

        <main class="dashboard-main connections-main">
            <section class="directory-heading">
                <div><p class="eyebrow">Build your network</p><h1>Your connections</h1><p>Manage your relationships and connection requests in one place.</p></div>
                <a class="button button-secondary" href="alumni.php">Find members <span aria-hidden="true">→</span></a>
            </section>

            <?php if (!empty($_SESSION['connection_success'])) : ?><div class="form-alert form-alert-success" role="status"><?php echo escape_html($_SESSION['connection_success']); ?></div><?php unset($_SESSION['connection_success']); endif; ?>
            <?php if (!empty($_SESSION['connection_errors'])) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($_SESSION['connection_errors'] as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php unset($_SESSION['connection_errors']); endif; ?>

            <?php
            $sections = array(
                array('title' => 'My Connections', 'eyebrow' => 'Your community', 'items' => $connections, 'empty' => 'You have not connected with anyone yet.', 'type' => 'connection'),
                array('title' => 'Received Requests', 'eyebrow' => 'Waiting for your response', 'items' => $receivedRequests, 'empty' => 'You have no pending received requests.', 'type' => 'received'),
                array('title' => 'Sent Requests', 'eyebrow' => 'Waiting for a response', 'items' => $sentRequests, 'empty' => 'You have no pending sent requests.', 'type' => 'sent'),
            );
            foreach ($sections as $section) :
            ?>
                <section class="connections-section dashboard-panel">
                    <div class="panel-heading"><div><p class="panel-eyebrow"><?php echo escape_html($section['eyebrow']); ?></p><h2><?php echo escape_html($section['title']); ?></h2></div><span class="directory-count"><?php echo count($section['items']); ?></span></div>
                    <?php if (empty($section['items'])) : ?>
                        <p class="empty-state"><?php echo escape_html($section['empty']); ?></p>
                    <?php else : ?>
                        <div class="connection-card-grid">
                            <?php foreach ($section['items'] as $member) : ?>
                                <?php $memberImage = !empty($member['profile_image']) ? basename($member['profile_image']) : ''; ?>
                                <article class="connection-card">
                                    <div class="connection-card-identity">
                                        <?php if ($memberImage !== '') : ?><img class="connection-avatar" src="uploads/profiles/<?php echo escape_html($memberImage); ?>" alt="<?php echo escape_html($member['name']); ?> profile image"><?php else : ?><span class="connection-avatar connection-avatar-fallback"><?php echo escape_html(strtoupper(substr($member['name'], 0, 1))); ?></span><?php endif; ?>
                                        <div><h3><?php echo escape_html($member['name']); ?></h3><span class="member-role-badge"><?php echo escape_html(ucfirst($member['role'])); ?></span></div>
                                    </div>
                                    <div class="connection-details">
                                        <?php if (!empty($member['department'])) : ?><span>▦ <?php echo escape_html($member['department']); ?></span><?php endif; ?>
                                        <?php if (!empty($member['graduation_year'])) : ?><span>◷ Class of <?php echo escape_html($member['graduation_year']); ?></span><?php endif; ?>
                                        <?php if (!empty($member['designation']) || !empty($member['company'])) : ?><span>↗ <?php echo escape_html($member['designation'] ?: 'Professional'); ?><?php if (!empty($member['company'])) : ?> · <?php echo escape_html($member['company']); ?><?php endif; ?></span><?php endif; ?>
                                        <?php if (!empty($member['city'])) : ?><span>⌖ <?php echo escape_html($member['city']); ?></span><?php endif; ?>
                                    </div>
                                    <div class="connection-card-actions">
                                        <a class="button button-secondary" href="view-profile.php?id=<?php echo (int) $member['member_id']; ?>">View profile</a>
                                        <?php if ($section['type'] === 'received') : ?>
                                            <form action="actions/connection.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="accept"><input type="hidden" name="connection_id" value="<?php echo (int) $member['id']; ?>"><button class="button button-primary" type="submit">Accept</button></form>
                                            <form action="actions/connection.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="reject"><input type="hidden" name="connection_id" value="<?php echo (int) $member['id']; ?>"><button class="button button-danger" type="submit">Reject</button></form>
                                        <?php elseif ($section['type'] === 'sent') : ?>
                                            <form action="actions/connection.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="cancel"><input type="hidden" name="connection_id" value="<?php echo (int) $member['id']; ?>"><button class="button button-secondary" type="submit">Cancel request</button></form>
                                        <?php else : ?>
                                            <form action="actions/connection.php" method="post" onsubmit="return confirm('Remove this connection?');"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="remove"><input type="hidden" name="connection_id" value="<?php echo (int) $member['id']; ?>"><button class="button button-danger" type="submit">Remove</button></form>
                                        <?php endif; ?>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            <?php endforeach; ?>
        </main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>