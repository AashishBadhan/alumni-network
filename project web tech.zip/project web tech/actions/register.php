<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../register.php');
    exit;
}

$name = trim(isset($_POST['name']) ? $_POST['name'] : '');
$email = trim(isset($_POST['email']) ? $_POST['email'] : '');
$password = isset($_POST['password']) ? $_POST['password'] : '';
$confirmPassword = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
$role = isset($_POST['role']) ? $_POST['role'] : '';
$errors = array();

if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    $errors[] = 'Your form session expired. Please try again.';
}
if ($name === '' || strlen($name) > 100) {
    $errors[] = 'Please enter a valid name.';
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
    $errors[] = 'Please enter a valid email address.';
}
if (!in_array($role, array('student', 'alumni'), true)) {
    $errors[] = 'Please select a valid account type.';
}
if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password)) {
    $errors[] = 'Password must be at least 8 characters and include uppercase, lowercase and numeric characters.';
}
if ($password !== $confirmPassword) {
    $errors[] = 'Passwords do not match.';
}

if (!empty($errors)) {
    $_SESSION['registration_errors'] = $errors;
    $_SESSION['registration_old_input'] = array('name' => $name, 'email' => $email, 'role' => $role);
    header('Location: ../register.php');
    exit;
}

try {
    $pdo->beginTransaction();
    $statement = $pdo->prepare(
        'INSERT INTO users (name, email, password, role, status)
         VALUES (:name, :email, :password, :role, :status)'
    );
    $statement->execute(array(
        ':name' => $name,
        ':email' => $email,
        ':password' => password_hash($password, PASSWORD_DEFAULT),
        ':role' => $role,
        ':status' => 'active',
    ));

    $profileStatement = $pdo->prepare('INSERT INTO profiles (user_id) VALUES (:user_id)');
    $profileStatement->execute(array(':user_id' => $pdo->lastInsertId()));
    $pdo->commit();

    header('Location: ../login.php?registered=1');
    exit;
} catch (PDOException $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log('AlumniConnect registration failed. PDO error code: ' . $exception->getCode());
    $_SESSION['registration_errors'] = array(
        $exception->getCode() === '23000'
            ? 'An account could not be created with those details. Please check the information and try again.'
            : 'We could not create your account right now. Please try again later.',
    );
    $_SESSION['registration_old_input'] = array('name' => $name, 'email' => $email, 'role' => $role);
    header('Location: ../register.php');
    exit;
}