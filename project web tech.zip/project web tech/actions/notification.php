<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../notifications.php');
    exit;
}

$currentUser = get_current_user_info();
if ($currentUser === null) {
    header('Location: ../login.php');
    exit;
}

$action = isset($_POST['action']) ? $_POST['action'] : '';
$notificationId = filter_var(isset($_POST['notification_id']) ? $_POST['notification_id'] : null, FILTER_VALIDATE_INT);
$errors = array();

if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    $errors[] = 'Your form session expired. Please try again.';
}
if (!in_array($action, array('mark_read', 'mark_all_read', 'delete'), true)) {
    $errors[] = 'The requested notification action is invalid.';
}
if (in_array($action, array('mark_read', 'delete'), true) && ($notificationId === false || $notificationId < 1)) {
    $errors[] = 'The notification could not be identified.';
}

if (!empty($errors)) {
    $_SESSION['notification_errors'] = $errors;
    header('Location: ../notifications.php');
    exit;
}

try {
    if ($action === 'mark_read') {
        $statement = $pdo->prepare(
            'UPDATE notifications SET is_read = 1
             WHERE id = :notification_id AND user_id = :user_id'
        );
        $statement->execute(array(':notification_id' => $notificationId, ':user_id' => $currentUser['id']));
        if ($statement->rowCount() !== 1) {
            $errors[] = 'This notification is not available.';
        } else {
            $_SESSION['notification_success'] = 'Notification marked as read.';
        }
    } elseif ($action === 'mark_all_read') {
        $statement = $pdo->prepare(
            'UPDATE notifications SET is_read = 1
             WHERE user_id = :user_id AND is_read = 0'
        );
        $statement->execute(array(':user_id' => $currentUser['id']));
        $_SESSION['notification_success'] = 'All notifications marked as read.';
    } elseif ($action === 'delete') {
        $statement = $pdo->prepare(
            'DELETE FROM notifications
             WHERE id = :notification_id AND user_id = :user_id'
        );
        $statement->execute(array(':notification_id' => $notificationId, ':user_id' => $currentUser['id']));
        if ($statement->rowCount() !== 1) {
            $errors[] = 'This notification is not available.';
        } else {
            $_SESSION['notification_success'] = 'Notification deleted.';
        }
    }
} catch (PDOException $exception) {
    error_log('AlumniConnect notification action failed. PDO error code: ' . $exception->getCode());
    $errors[] = 'We could not complete that notification action right now.';
}

if (!empty($errors)) {
    $_SESSION['notification_errors'] = $errors;
    unset($_SESSION['notification_success']);
}

header('Location: ../notifications.php');
exit;