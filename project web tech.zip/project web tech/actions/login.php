<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit;
}

$email = trim(isset($_POST['email']) ? $_POST['email'] : '');
$password = isset($_POST['password']) ? $_POST['password'] : '';
$errors = array();

if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    $errors[] = 'Your form session expired. Please try again.';
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150 || $password === '') {
    $errors[] = 'The email or password is incorrect.';
}

if (empty($errors)) {
    try {
        $statement = $pdo->prepare(
            'SELECT id, name, email, password, role, status
             FROM users
             WHERE email = :email
             LIMIT 1'
        );
        $statement->execute(array(':email' => $email));
        $user = $statement->fetch();

        if ($user === false || $user['status'] !== 'active' || !password_verify($password, $user['password'])) {
            $errors[] = 'The email or password is incorrect.';
        }
    } catch (PDOException $exception) {
        error_log('AlumniConnect login failed. PDO error code: ' . $exception->getCode());
        $errors[] = 'We could not sign you in right now. Please try again later.';
    }
}

if (!empty($errors)) {
    $_SESSION['login_errors'] = $errors;
    $_SESSION['login_email'] = $email;
    header('Location: ../login.php');
    exit;
}

session_regenerate_id(true);
$_SESSION['user_id'] = (int) $user['id'];
$_SESSION['user_name'] = $user['name'];
$_SESSION['user_role'] = $user['role'];
header('Location: ../dashboard.php');
exit;