<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../events.php');
    exit;
}
$currentUser = get_current_user_info();
if ($currentUser === null) {
    header('Location: ../login.php');
    exit;
}

$action = isset($_POST['action']) ? $_POST['action'] : '';
$eventId = filter_var(isset($_POST['event_id']) ? $_POST['event_id'] : null, FILTER_VALIDATE_INT);
$redirect = '../events.php';
$errors = array();
$input = array(
    'title' => trim(isset($_POST['title']) ? $_POST['title'] : ''),
    'description' => trim(isset($_POST['description']) ? $_POST['description'] : ''),
    'event_date' => trim(isset($_POST['event_date']) ? $_POST['event_date'] : ''),
    'location' => trim(isset($_POST['location']) ? $_POST['location'] : ''),
    'category' => trim(isset($_POST['category']) ? $_POST['category'] : ''),
);

if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    $errors[] = 'Your form session expired. Please try again.';
}

if (in_array($action, array('create', 'update'), true)) {
    if ($input['title'] === '' || strlen($input['title']) > 200) {
        $errors[] = 'Please enter an event title.';
    }
    if ($input['description'] === '' || strlen($input['description']) > 5000) {
        $errors[] = 'Please enter an event description.';
    }
    if ($input['location'] === '' || strlen($input['location']) > 200) {
        $errors[] = 'Please enter a valid location.';
    }
    if ($input['category'] === '' || strlen($input['category']) > 100) {
        $errors[] = 'Please enter a valid category.';
    }
    $eventDate = DateTime::createFromFormat('Y-m-d\TH:i', $input['event_date']);
    if ($eventDate === false || $eventDate->format('Y-m-d\TH:i') !== $input['event_date']) {
        $errors[] = 'Please enter a valid event date and time.';
    } elseif ($eventDate->getTimestamp() <= time()) {
        $errors[] = 'Events must be scheduled for a future date and time.';
    }
    if ($action === 'update' && ($eventId === false || $eventId < 1)) {
        $errors[] = 'The event could not be identified.';
    }
} elseif (!in_array($action, array('register', 'cancel', 'delete'), true) || $eventId === false || $eventId < 1) {
    $errors[] = 'The requested event action is invalid.';
}

if (!empty($errors)) {
    $_SESSION['event_errors'] = $errors;
    if (in_array($action, array('create', 'update'), true)) {
        $_SESSION['event_old_input'] = $input;
        $redirect = $action === 'update' && $eventId !== false ? '../edit-event.php?id=' . (int) $eventId : '../create-event.php';
    }
    header('Location: ' . $redirect);
    exit;
}

try {
    $accountStatement = $pdo->prepare('SELECT role, status FROM users WHERE id = :user_id LIMIT 1');
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }
    $currentUser['role'] = $account['role'];

    if ($action === 'create') {
        $statement = $pdo->prepare(
            'INSERT INTO events (user_id, title, description, event_date, location, category)
             VALUES (:user_id, :title, :description, :event_date, :location, :category)'
        );
        $statement->execute(array(':user_id' => $currentUser['id'], ':title' => $input['title'], ':description' => $input['description'], ':event_date' => $eventDate->format('Y-m-d H:i:s'), ':location' => $input['location'], ':category' => $input['category']));
        $_SESSION['event_success'] = 'Your event was created successfully.';
    } elseif ($action === 'update') {
        $eventStatement = $pdo->prepare('SELECT id, user_id, title FROM events WHERE id = :event_id LIMIT 1');
        $eventStatement->execute(array(':event_id' => $eventId));
        $event = $eventStatement->fetch();
        if ($event === false || ((int) $event['user_id'] !== (int) $currentUser['id'] && $currentUser['role'] !== 'admin')) {
            http_response_code(403);
            exit('You do not have permission to edit this event.');
        }
        $statement = $pdo->prepare(
            'UPDATE events SET title = :title, description = :description, event_date = :event_date, location = :location, category = :category
             WHERE id = :event_id'
        );
        $statement->execute(array(':title' => $input['title'], ':description' => $input['description'], ':event_date' => $eventDate->format('Y-m-d H:i:s'), ':location' => $input['location'], ':category' => $input['category'], ':event_id' => $eventId));
        $attendeeStatement = $pdo->prepare('SELECT user_id FROM event_registrations WHERE event_id = :event_id AND user_id <> :creator_id');
        $attendeeStatement->execute(array(':event_id' => $eventId, ':creator_id' => $event['user_id']));
        $notification = $pdo->prepare(
            "INSERT INTO notifications (user_id, message, type, related_id)
             SELECT :notify_user, :notify_message, 'event_updated', :notify_related
             FROM DUAL
             WHERE NOT EXISTS (
                 SELECT 1 FROM notifications WHERE user_id = :check_user AND type = 'event_updated'
                   AND related_id = :check_related AND message = :check_message
             )"
        );
        foreach ($attendeeStatement->fetchAll() as $attendee) {
            $message = 'The event "' . $input['title'] . '" has been updated.';
            $notification->execute(array(':notify_user' => $attendee['user_id'], ':notify_message' => $message, ':notify_related' => $eventId, ':check_user' => $attendee['user_id'], ':check_related' => $eventId, ':check_message' => $message));
        }
        $_SESSION['event_success'] = 'Your event was updated successfully.';
    } elseif ($action === 'register') {
        $eventStatement = $pdo->prepare('SELECT id, user_id, title, event_date FROM events WHERE id = :event_id LIMIT 1');
        $eventStatement->execute(array(':event_id' => $eventId));
        $event = $eventStatement->fetch();
        if ($event === false || strtotime($event['event_date']) <= time()) {
            $_SESSION['event_errors'] = array('You cannot register for a past event.');
        } else {
            $pdo->beginTransaction();
            $registration = $pdo->prepare('INSERT INTO event_registrations (event_id, user_id) VALUES (:event_id, :user_id)');
            try {
                $registration->execute(array(':event_id' => $eventId, ':user_id' => $currentUser['id']));
                if ((int) $event['user_id'] !== (int) $currentUser['id']) {
                    $message = $currentUser['name'] . ' registered for your event "' . $event['title'] . '".';
                    $notification = $pdo->prepare("INSERT INTO notifications (user_id, message, type, related_id) SELECT :notify_user, :notify_message, 'event_registration', :notify_related FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM notifications WHERE user_id = :check_user AND type = 'event_registration' AND related_id = :check_related AND message = :check_message)");
                    $notification->execute(array(':notify_user' => $event['user_id'], ':notify_message' => $message, ':notify_related' => $eventId, ':check_user' => $event['user_id'], ':check_related' => $eventId, ':check_message' => $message));
                }
                $pdo->commit();
                $_SESSION['event_success'] = 'You are registered for this event.';
            } catch (PDOException $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $_SESSION['event_errors'] = $exception->getCode() === '23000' ? array('You are already registered for this event.') : array('We could not register you for this event.');
            }
        }
    } elseif ($action === 'cancel') {
        $statement = $pdo->prepare('DELETE FROM event_registrations WHERE event_id = :event_id AND user_id = :user_id');
        $statement->execute(array(':event_id' => $eventId, ':user_id' => $currentUser['id']));
        $_SESSION['event_success'] = 'Your event registration was cancelled.';
    } elseif ($action === 'delete') {
        $eventStatement = $pdo->prepare('SELECT id, user_id, title FROM events WHERE id = :event_id LIMIT 1');
        $eventStatement->execute(array(':event_id' => $eventId));
        $event = $eventStatement->fetch();
        if ($event === false || ((int) $event['user_id'] !== (int) $currentUser['id'] && $currentUser['role'] !== 'admin')) {
            http_response_code(403);
            exit('You do not have permission to delete this event.');
        }
        $attendeeStatement = $pdo->prepare('SELECT user_id FROM event_registrations WHERE event_id = :event_id AND user_id <> :creator_id');
        $attendeeStatement->execute(array(':event_id' => $eventId, ':creator_id' => $event['user_id']));
        $notification = $pdo->prepare("INSERT INTO notifications (user_id, message, type, related_id) SELECT :notify_user, :notify_message, 'event_deleted', NULL FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM notifications WHERE user_id = :check_user AND type = 'event_deleted' AND message = :check_message)");
        foreach ($attendeeStatement->fetchAll() as $attendee) {
            $message = 'The event "' . $event['title'] . '" has been cancelled.';
            $notification->execute(array(':notify_user' => $attendee['user_id'], ':notify_message' => $message, ':check_user' => $attendee['user_id'], ':check_message' => $message));
        }
        $statement = $pdo->prepare('DELETE FROM events WHERE id = :event_id');
        $statement->execute(array(':event_id' => $eventId));
        $_SESSION['event_success'] = 'The event was deleted.';
    }
} catch (PDOException $exception) {
    error_log('AlumniConnect event action failed. PDO error code: ' . $exception->getCode());
    $_SESSION['event_errors'] = array('We could not complete that event action right now.');
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
}

if ($action === 'update' || $action === 'delete' || $action === 'register' || $action === 'cancel') {
    $redirect = $action === 'update' || $action === 'delete' ? '../events.php' : '../events.php?view=' . (int) $eventId;
}
header('Location: ' . $redirect);
exit;