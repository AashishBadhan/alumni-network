<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../connections.php');
    exit;
}

$currentUser = get_current_user_info();
if ($currentUser === null) {
    header('Location: ../login.php');
    exit;
}

$action = isset($_POST['action']) ? $_POST['action'] : '';
$targetId = filter_var(isset($_POST['target_id']) ? $_POST['target_id'] : null, FILTER_VALIDATE_INT);
$connectionId = filter_var(isset($_POST['connection_id']) ? $_POST['connection_id'] : null, FILTER_VALIDATE_INT);
$errors = array();

if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    $errors[] = 'Your form session expired. Please try again.';
}

if (!in_array($action, array('send', 'accept', 'reject', 'cancel', 'remove'), true)) {
    $errors[] = 'The requested connection action is invalid.';
}

if ($action === 'send' && ($targetId === false || $targetId < 1 || (int) $targetId === (int) $currentUser['id'])) {
    $errors[] = 'You cannot send a connection request to this user.';
}
if ($action !== 'send' && ($connectionId === false || $connectionId < 1)) {
    $errors[] = 'The connection could not be identified.';
}

if (!empty($errors)) {
    $_SESSION['connection_errors'] = $errors;
    header('Location: ../connections.php');
    exit;
}

try {
    $accountStatement = $pdo->prepare('SELECT status FROM users WHERE id = :user_id LIMIT 1');
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }

    if ($action === 'send') {
        $targetStatement = $pdo->prepare(
            "SELECT id, name FROM users
             WHERE id = :target_id AND status = 'active' LIMIT 1"
        );
        $targetStatement->execute(array(':target_id' => $targetId));
        $target = $targetStatement->fetch();
        if ($target === false) {
            $errors[] = 'This user is not available for a connection request.';
        } else {
            $pairLow = min((int) $currentUser['id'], (int) $targetId);
            $pairHigh = max((int) $currentUser['id'], (int) $targetId);
            $pdo->beginTransaction();
            $existingStatement = $pdo->prepare(
                'SELECT id, status FROM connections
                 WHERE pair_low_id = :pair_low AND pair_high_id = :pair_high
                 LIMIT 1'
            );
            $existingStatement->execute(array(':pair_low' => $pairLow, ':pair_high' => $pairHigh));
            $existing = $existingStatement->fetch();

            if ($existing !== false && in_array($existing['status'], array('pending', 'accepted'), true)) {
                $errors[] = $existing['status'] === 'accepted'
                    ? 'You are already connected with this user.'
                    : 'A connection request already exists for this user.';
            } elseif ($existing !== false) {
                $updateStatement = $pdo->prepare(
                    "UPDATE connections
                     SET sender_id = :sender_id, receiver_id = :receiver_id,
                         pair_low_id = :pair_low, pair_high_id = :pair_high, status = 'pending'
                     WHERE id = :connection_id"
                );
                $updateStatement->execute(array(
                    ':sender_id' => $currentUser['id'],
                    ':receiver_id' => $targetId,
                    ':pair_low' => $pairLow,
                    ':pair_high' => $pairHigh,
                    ':connection_id' => $existing['id'],
                ));
                $connectionId = (int) $existing['id'];
            } else {
                $insertStatement = $pdo->prepare(
                    'INSERT INTO connections
                        (sender_id, receiver_id, pair_low_id, pair_high_id, status)
                     VALUES (:sender_id, :receiver_id, :pair_low, :pair_high, \'pending\')'
                );
                $insertStatement->execute(array(
                    ':sender_id' => $currentUser['id'],
                    ':receiver_id' => $targetId,
                    ':pair_low' => $pairLow,
                    ':pair_high' => $pairHigh,
                ));
                $connectionId = (int) $pdo->lastInsertId();
            }

            if (empty($errors)) {
                $message = $currentUser['name'] . ' sent you a connection request.';
                $notificationStatement = $pdo->prepare(
                    "INSERT INTO notifications (user_id, message, type, related_id)
                     SELECT :user_id, :message, 'connection_request', :related_id
                     FROM DUAL
                     WHERE NOT EXISTS (
                         SELECT 1 FROM notifications
                         WHERE user_id = :check_user AND type = 'connection_request'
                           AND related_id = :check_related AND message = :check_message
                     )"
                );
                $notificationStatement->execute(array(
                    ':user_id' => $targetId,
                    ':message' => $message,
                    ':related_id' => $connectionId,
                    ':check_user' => $targetId,
                    ':check_related' => $connectionId,
                    ':check_message' => $message,
                ));
                $pdo->commit();
                $_SESSION['connection_success'] = 'Your connection request was sent.';
            } elseif ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
        }
    } elseif ($action === 'accept') {
        $requestStatement = $pdo->prepare(
            "SELECT sender_id, receiver_id
             FROM connections
             WHERE id = :connection_id AND receiver_id = :user_id AND status = 'pending'
             LIMIT 1"
        );
        $requestStatement->execute(array(':connection_id' => $connectionId, ':user_id' => $currentUser['id']));
        $request = $requestStatement->fetch();
        if ($request === false) {
            $errors[] = 'This request is no longer available.';
        } else {
            $pairLow = min((int) $request['sender_id'], (int) $request['receiver_id']);
            $pairHigh = max((int) $request['sender_id'], (int) $request['receiver_id']);
        }
        $statement = $pdo->prepare(
            "UPDATE connections
             SET status = 'accepted', pair_low_id = :pair_low, pair_high_id = :pair_high
             WHERE id = :connection_id AND receiver_id = :user_id AND status = 'pending'"
        );
        if ($request !== false) {
            $statement->execute(array(
                ':pair_low' => $pairLow,
                ':pair_high' => $pairHigh,
                ':connection_id' => $connectionId,
                ':user_id' => $currentUser['id'],
            ));
            if ($statement->rowCount() !== 1) {
                $errors[] = 'This request is no longer available.';
            } else {
                $message = $currentUser['name'] . ' accepted your connection request.';
                $notificationStatement = $pdo->prepare(
                    "INSERT INTO notifications (user_id, message, type, related_id)
                     SELECT :user_id, :message, 'connection_accepted', :related_id
                     FROM DUAL
                     WHERE NOT EXISTS (
                         SELECT 1 FROM notifications
                         WHERE user_id = :check_user AND type = 'connection_accepted'
                           AND related_id = :check_related
                     )"
                );
                $notificationStatement->execute(array(
                    ':user_id' => $request['sender_id'],
                    ':message' => $message,
                    ':related_id' => $connectionId,
                    ':check_user' => $request['sender_id'],
                    ':check_related' => $connectionId,
                ));
                $_SESSION['connection_success'] = 'Connection request accepted.';
            }
        }
    } elseif ($action === 'reject') {
        $requestStatement = $pdo->prepare(
            "SELECT sender_id, receiver_id
             FROM connections
             WHERE id = :connection_id AND receiver_id = :user_id AND status = 'pending'
             LIMIT 1"
        );
        $requestStatement->execute(array(':connection_id' => $connectionId, ':user_id' => $currentUser['id']));
        $request = $requestStatement->fetch();
        if ($request === false) {
            $errors[] = 'This request is no longer available.';
        } else {
            $pairLow = min((int) $request['sender_id'], (int) $request['receiver_id']);
            $pairHigh = max((int) $request['sender_id'], (int) $request['receiver_id']);
        }
        $statement = $pdo->prepare(
            "UPDATE connections
             SET status = 'rejected', pair_low_id = :pair_low, pair_high_id = :pair_high
             WHERE id = :connection_id AND receiver_id = :user_id AND status = 'pending'"
        );
        if ($request !== false) {
            $statement->execute(array(
                ':pair_low' => $pairLow,
                ':pair_high' => $pairHigh,
                ':connection_id' => $connectionId,
                ':user_id' => $currentUser['id'],
            ));
            if ($statement->rowCount() !== 1) {
                $errors[] = 'This request is no longer available.';
            } else {
                $_SESSION['connection_success'] = 'Connection request rejected.';
            }
        }
    } elseif ($action === 'cancel') {
        $statement = $pdo->prepare(
            "DELETE FROM connections
             WHERE id = :connection_id AND sender_id = :user_id AND status = 'pending'"
        );
        $statement->execute(array(':connection_id' => $connectionId, ':user_id' => $currentUser['id']));
        if ($statement->rowCount() === 1) {
            $_SESSION['connection_success'] = 'Connection request cancelled.';
        } else {
            $errors[] = 'This request is no longer available.';
        }
    } elseif ($action === 'remove') {
        $statement = $pdo->prepare(
            "DELETE FROM connections
             WHERE id = :connection_id
               AND (sender_id = :sender_id OR receiver_id = :receiver_id)
               AND status = 'accepted'"
        );
        $statement->execute(array(
            ':connection_id' => $connectionId,
            ':sender_id' => $currentUser['id'],
            ':receiver_id' => $currentUser['id'],
        ));
        if ($statement->rowCount() === 1) {
            $_SESSION['connection_success'] = 'Connection removed.';
        } else {
            $errors[] = 'This connection is no longer available.';
        }
    }
} catch (PDOException $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('AlumniConnect connection action failed. PDO error code: ' . $exception->getCode());
    $errors[] = $exception->getCode() === '23000'
        ? 'A connection request already exists for this user.'
        : 'We could not complete that connection action right now.';
}

if (!empty($errors)) {
    $_SESSION['connection_errors'] = $errors;
}

header('Location: ../connections.php');
exit;