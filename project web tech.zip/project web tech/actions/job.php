<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../jobs.php');
    exit;
}

$currentUser = get_current_user_info();
if ($currentUser === null) {
    header('Location: ../login.php');
    exit;
}

$action = isset($_POST['action']) ? $_POST['action'] : '';
$jobId = filter_var(isset($_POST['job_id']) ? $_POST['job_id'] : null, FILTER_VALIDATE_INT);
$input = array(
    'title' => trim(isset($_POST['title']) ? $_POST['title'] : ''),
    'company' => trim(isset($_POST['company']) ? $_POST['company'] : ''),
    'location' => trim(isset($_POST['location']) ? $_POST['location'] : ''),
    'job_type' => trim(isset($_POST['job_type']) ? $_POST['job_type'] : ''),
    'experience' => trim(isset($_POST['experience']) ? $_POST['experience'] : ''),
    'salary' => trim(isset($_POST['salary']) ? $_POST['salary'] : ''),
    'description' => trim(isset($_POST['description']) ? $_POST['description'] : ''),
    'skills' => trim(isset($_POST['skills']) ? $_POST['skills'] : ''),
    'apply_link' => trim(isset($_POST['apply_link']) ? $_POST['apply_link'] : ''),
);
$errors = array();

if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    $errors[] = 'Your form session expired. Please try again.';
}

if (in_array($action, array('create', 'update'), true)) {
    foreach (array('title' => 200, 'company' => 150, 'location' => 150, 'job_type' => 50, 'experience' => 100) as $field => $maxLength) {
        if ($input[$field] === '' || strlen($input[$field]) > $maxLength) {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required and must be within the allowed length.';
        }
    }
    foreach (array('salary' => 100, 'description' => 5000, 'skills' => 2000, 'apply_link' => 500) as $field => $maxLength) {
        if ($input[$field] === '' || strlen($input[$field]) > $maxLength) {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required and must be within the allowed length.';
        }
    }
    $scheme = strtolower((string) parse_url($input['apply_link'], PHP_URL_SCHEME));
    if (!filter_var($input['apply_link'], FILTER_VALIDATE_URL) || !in_array($scheme, array('http', 'https'), true)) {
        $errors[] = 'Application link must be a valid HTTP or HTTPS URL.';
    }
    if ($action === 'update' && ($jobId === false || $jobId < 1)) {
        $errors[] = 'The job could not be identified.';
    }
} elseif ($action === 'delete' && ($jobId === false || $jobId < 1)) {
    $errors[] = 'The job could not be identified.';
} elseif (!in_array($action, array('create', 'update', 'delete'), true)) {
    $errors[] = 'The requested job action is invalid.';
}

if (!empty($errors)) {
    $_SESSION['job_errors'] = $errors;
    if (in_array($action, array('create', 'update'), true)) {
        $_SESSION['job_old_input'] = $input;
        $redirect = $action === 'update' && $jobId !== false ? '../edit-job.php?id=' . (int) $jobId : '../create-job.php';
    } else {
        $redirect = '../jobs.php';
    }
    header('Location: ' . $redirect);
    exit;
}

try {
    $accountStatement = $pdo->prepare('SELECT role, status FROM users WHERE id = :user_id LIMIT 1');
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }
    $currentUser['role'] = $account['role'];

    if ($action === 'create') {
        $statement = $pdo->prepare(
            'INSERT INTO jobs (user_id, title, company, location, job_type, experience, salary, description, skills, apply_link)
             VALUES (:user_id, :title, :company, :location, :job_type, :experience, :salary, :description, :skills, :apply_link)'
        );
        $statement->execute(array(
            ':user_id' => $currentUser['id'],
            ':title' => $input['title'],
            ':company' => $input['company'],
            ':location' => $input['location'],
            ':job_type' => $input['job_type'],
            ':experience' => $input['experience'],
            ':salary' => $input['salary'],
            ':description' => $input['description'],
            ':skills' => $input['skills'],
            ':apply_link' => $input['apply_link'],
        ));
        $_SESSION['job_success'] = 'Your job was posted successfully.';
    } elseif ($action === 'update') {
        $ownerStatement = $pdo->prepare('SELECT user_id FROM jobs WHERE id = :job_id LIMIT 1');
        $ownerStatement->execute(array(':job_id' => $jobId));
        $job = $ownerStatement->fetch();
        if ($job === false || ((int) $job['user_id'] !== (int) $currentUser['id'] && $currentUser['role'] !== 'admin')) {
            http_response_code(403);
            exit('You do not have permission to edit this job.');
        }
        $statement = $pdo->prepare(
            'UPDATE jobs SET title = :title, company = :company, location = :location,
             job_type = :job_type, experience = :experience, salary = :salary,
             description = :description, skills = :skills, apply_link = :apply_link
             WHERE id = :job_id'
        );
        $statement->execute(array(
            ':title' => $input['title'],
            ':company' => $input['company'],
            ':location' => $input['location'],
            ':job_type' => $input['job_type'],
            ':experience' => $input['experience'],
            ':salary' => $input['salary'],
            ':description' => $input['description'],
            ':skills' => $input['skills'],
            ':apply_link' => $input['apply_link'],
            ':job_id' => $jobId,
        ));
        $_SESSION['job_success'] = 'Your job was updated successfully.';
    } elseif ($action === 'delete') {
        $ownerStatement = $pdo->prepare('SELECT user_id FROM jobs WHERE id = :job_id LIMIT 1');
        $ownerStatement->execute(array(':job_id' => $jobId));
        $job = $ownerStatement->fetch();
        if ($job === false || ((int) $job['user_id'] !== (int) $currentUser['id'] && $currentUser['role'] !== 'admin')) {
            http_response_code(403);
            exit('You do not have permission to delete this job.');
        }
        $statement = $pdo->prepare('DELETE FROM jobs WHERE id = :job_id');
        $statement->execute(array(':job_id' => $jobId));
        $_SESSION['job_success'] = 'The job was deleted.';
    }
} catch (PDOException $exception) {
    error_log('AlumniConnect job action failed. PDO error code: ' . $exception->getCode());
    $_SESSION['job_errors'] = array('We could not complete that job action right now.');
}

header('Location: ../jobs.php');
exit;