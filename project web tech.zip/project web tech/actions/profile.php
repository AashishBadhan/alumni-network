<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

start_secure_session();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../profile.php');
    exit;
}

$currentUser = get_current_user_info();
if ($currentUser === null) {
    header('Location: ../login.php');
    exit;
}

$redirectWithErrors = function ($errors, $input) {
    $_SESSION['profile_errors'] = $errors;
    $_SESSION['profile_old_input'] = $input;
    header('Location: ../edit-profile.php');
    exit;
};

$input = array(
    'name' => trim(isset($_POST['name']) ? $_POST['name'] : ''),
    'department' => trim(isset($_POST['department']) ? $_POST['department'] : ''),
    'graduation_year' => trim(isset($_POST['graduation_year']) ? $_POST['graduation_year'] : ''),
    'phone' => trim(isset($_POST['phone']) ? $_POST['phone'] : ''),
    'city' => trim(isset($_POST['city']) ? $_POST['city'] : ''),
    'bio' => trim(isset($_POST['bio']) ? $_POST['bio'] : ''),
    'education' => trim(isset($_POST['education']) ? $_POST['education'] : ''),
    'skills' => trim(isset($_POST['skills']) ? $_POST['skills'] : ''),
    'company' => trim(isset($_POST['company']) ? $_POST['company'] : ''),
    'designation' => trim(isset($_POST['designation']) ? $_POST['designation'] : ''),
    'linkedin' => trim(isset($_POST['linkedin']) ? $_POST['linkedin'] : ''),
    'github' => trim(isset($_POST['github']) ? $_POST['github'] : ''),
);
$errors = array();

if (!verify_csrf_token(isset($_POST['csrf_token']) ? $_POST['csrf_token'] : null)) {
    $errors[] = 'Your form session expired. Please try again.';
}
if ($input['name'] === '' || strlen($input['name']) > 100) {
    $errors[] = 'Please enter a valid full name.';
}
foreach (array('department' => 100, 'phone' => 20, 'city' => 100, 'company' => 150, 'designation' => 150) as $field => $maxLength) {
    if (strlen($input[$field]) > $maxLength) {
        $errors[] = ucfirst($field) . ' is too long.';
    }
}
foreach (array('bio' => 'Bio', 'education' => 'Education', 'skills' => 'Skills') as $field => $label) {
    if (strlen($input[$field]) > 2000) {
        $errors[] = $label . ' must be 2000 characters or fewer.';
    }
}
if ($input['graduation_year'] !== '' && (!ctype_digit($input['graduation_year']) || (int) $input['graduation_year'] < 1901 || (int) $input['graduation_year'] > (int) date('Y') + 10)) {
    $errors[] = 'Please enter a valid graduation year.';
}
foreach (array('linkedin' => 'LinkedIn', 'github' => 'GitHub') as $field => $label) {
    if ($input[$field] !== '' && (!filter_var($input[$field], FILTER_VALIDATE_URL) || !in_array(strtolower(parse_url($input[$field], PHP_URL_SCHEME)), array('http', 'https'), true))) {
        $errors[] = $label . ' must be a valid HTTP or HTTPS URL.';
    }
}

$newImagePath = '';
$oldImage = '';
try {
    $accountStatement = $pdo->prepare(
        "SELECT u.status, p.profile_image FROM users u
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE u.id = :user_id LIMIT 1"
    );
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }
    $oldImage = $account['profile_image'];

    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['profile_image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'The profile image could not be uploaded.';
        } elseif ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
            $errors[] = 'Profile images must be 2 MB or smaller.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($_FILES['profile_image']['tmp_name']);
            $allowedMimes = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp');
            if (!isset($allowedMimes[$mime]) || @getimagesize($_FILES['profile_image']['tmp_name']) === false) {
                $errors[] = 'Only valid JPEG, PNG or WebP images are allowed.';
            } else {
                $uploadDirectory = __DIR__ . '/../uploads/profiles/';
                $newImageName = bin2hex(random_bytes(16)) . '.' . $allowedMimes[$mime];
                $newImagePath = $uploadDirectory . $newImageName;
                if (!move_uploaded_file($_FILES['profile_image']['tmp_name'], $newImagePath)) {
                    $errors[] = 'The profile image could not be saved.';
                    $newImagePath = '';
                } else {
                    $input['profile_image'] = $newImageName;
                }
            }
        }
    }
} catch (PDOException $exception) {
    error_log('AlumniConnect profile validation query failed. PDO error code: ' . $exception->getCode());
    $errors[] = 'We could not update your profile right now. Please try again later.';
}

if (!empty($errors)) {
    if ($newImagePath !== '' && is_file($newImagePath)) {
        unlink($newImagePath);
    }
    $redirectWithErrors($errors, $input);
}

try {
    $pdo->beginTransaction();
    $profileStatement = $pdo->prepare(
        'INSERT INTO profiles
            (user_id, department, graduation_year, phone, city, bio, education, skills, company, designation, linkedin, github, profile_image)
         VALUES
            (:user_id, :department, :graduation_year, :phone, :city, :bio, :education, :skills, :company, :designation, :linkedin, :github, :profile_image)
         ON DUPLICATE KEY UPDATE
            department = VALUES(department), graduation_year = VALUES(graduation_year), phone = VALUES(phone),
            city = VALUES(city), bio = VALUES(bio), education = VALUES(education), skills = VALUES(skills),
            company = VALUES(company), designation = VALUES(designation), linkedin = VALUES(linkedin),
            github = VALUES(github), profile_image = VALUES(profile_image)'
    );
    $profileStatement->execute(array(
        ':user_id' => $currentUser['id'],
        ':department' => $input['department'] !== '' ? $input['department'] : null,
        ':graduation_year' => $input['graduation_year'] !== '' ? $input['graduation_year'] : null,
        ':phone' => $input['phone'] !== '' ? $input['phone'] : null,
        ':city' => $input['city'] !== '' ? $input['city'] : null,
        ':bio' => $input['bio'] !== '' ? $input['bio'] : null,
        ':education' => $input['education'] !== '' ? $input['education'] : null,
        ':skills' => $input['skills'] !== '' ? $input['skills'] : null,
        ':company' => $input['company'] !== '' ? $input['company'] : null,
        ':designation' => $input['designation'] !== '' ? $input['designation'] : null,
        ':linkedin' => $input['linkedin'] !== '' ? $input['linkedin'] : null,
        ':github' => $input['github'] !== '' ? $input['github'] : null,
        ':profile_image' => $newImagePath !== '' ? $input['profile_image'] : ($oldImage !== '' ? $oldImage : null),
    ));
    $userStatement = $pdo->prepare('UPDATE users SET name = :name WHERE id = :user_id AND status = :status');
    $userStatement->execute(array(':name' => $input['name'], ':user_id' => $currentUser['id'], ':status' => 'active'));
    $pdo->commit();
    $_SESSION['user_name'] = $input['name'];
    $_SESSION['profile_success'] = 'Your profile was updated successfully.';
    if ($newImagePath !== '' && $oldImage !== '' && basename($oldImage) !== basename($input['profile_image'])) {
        $oldPath = __DIR__ . '/../uploads/profiles/' . basename($oldImage);
        if (is_file($oldPath)) {
            unlink($oldPath);
        }
    }
    header('Location: ../profile.php');
    exit;
} catch (PDOException $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    if ($newImagePath !== '' && is_file($newImagePath)) {
        unlink($newImagePath);
    }
    error_log('AlumniConnect profile update failed. PDO error code: ' . $exception->getCode());
    $redirectWithErrors(array('We could not update your profile right now. Please try again later.'), $input);
}