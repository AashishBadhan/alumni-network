<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$dashboardData = array(
    'profile' => array(),
    'stats' => array(
        'students' => 0,
        'alumni' => 0,
        'jobs' => 0,
        'events' => 0,
    ),
    'members' => array(),
    'jobs' => array(),
    'events' => array(),
    'notifications' => array(),
    'connections' => 0,
    'pending_connections' => 0,
);

try {
    $accountStatement = $pdo->prepare(
        'SELECT u.id, u.name, u.role, u.status, p.department, p.company, p.designation,
                p.bio, p.profile_image, p.phone, p.city
         FROM users u
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE u.id = :user_id
         LIMIT 1'
    );
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();

    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: login.php');
        exit;
    }

    $dashboardData['profile'] = $account;

    $statsStatement = $pdo->prepare(
        "SELECT
            (SELECT COUNT(*) FROM users WHERE role = 'student' AND status = 'active') AS students,
            (SELECT COUNT(*) FROM users WHERE role = 'alumni' AND status = 'active') AS alumni,
            (SELECT COUNT(*) FROM jobs) AS jobs,
            (SELECT COUNT(*) FROM events WHERE event_date >= NOW()) AS events"
    );
    $statsStatement->execute();
    $stats = $statsStatement->fetch();
    if ($stats !== false) {
        $dashboardData['stats'] = array(
            'students' => (int) $stats['students'],
            'alumni' => (int) $stats['alumni'],
            'jobs' => (int) $stats['jobs'],
            'events' => (int) $stats['events'],
        );
    }

    $membersStatement = $pdo->prepare(
        'SELECT u.name, u.role, p.department, p.profile_image
         FROM users u
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE u.status = :status
         ORDER BY u.created_at DESC
         LIMIT 5'
    );
    $membersStatement->execute(array(':status' => 'active'));
    $dashboardData['members'] = $membersStatement->fetchAll();

    $jobsStatement = $pdo->prepare(
        'SELECT title, company, location, job_type, created_at
         FROM jobs
         ORDER BY created_at DESC
         LIMIT 4'
    );
    $jobsStatement->execute();
    $dashboardData['jobs'] = $jobsStatement->fetchAll();

    $eventsStatement = $pdo->prepare(
        'SELECT e.title, e.event_date, e.location, u.name AS creator_name
         FROM events e
         INNER JOIN users u ON u.id = e.user_id
         WHERE e.event_date >= NOW()
         ORDER BY e.event_date ASC
         LIMIT 4'
    );
    $eventsStatement->execute();
    $dashboardData['events'] = $eventsStatement->fetchAll();

    $notificationsStatement = $pdo->prepare(
        'SELECT message, type, created_at, is_read
         FROM notifications
         WHERE user_id = :user_id
         ORDER BY created_at DESC
         LIMIT 4'
    );
    $notificationsStatement->execute(array(':user_id' => $currentUser['id']));
    $dashboardData['notifications'] = $notificationsStatement->fetchAll();

    $connectionsStatement = $pdo->prepare(
        "SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status = 'pending' AND receiver_id = :user_id THEN 1 ELSE 0 END) AS pending
         FROM connections
         WHERE (sender_id = :sender_id OR receiver_id = :receiver_id)
           AND status IN ('pending', 'accepted')"
    );
    $connectionsStatement->execute(array(
        ':user_id' => $currentUser['id'],
        ':sender_id' => $currentUser['id'],
        ':receiver_id' => $currentUser['id'],
    ));
    $connections = $connectionsStatement->fetch();
    if ($connections !== false) {
        $dashboardData['connections'] = (int) $connections['total'];
        $dashboardData['pending_connections'] = (int) $connections['pending'];
    }
} catch (PDOException $exception) {
    error_log('AlumniConnect dashboard query failed. PDO error code: ' . $exception->getCode());
    $dashboardData['profile'] = array(
        'name' => $currentUser['name'],
        'role' => $currentUser['role'],
    );
}

$profile = $dashboardData['profile'];
$profileName = isset($profile['name']) ? $profile['name'] : $currentUser['name'];
$profileInitial = strtoupper(substr($profileName, 0, 1));
$profileFields = array('department', 'graduation_year', 'phone', 'city', 'bio', 'company', 'designation', 'skills', 'education', 'linkedin', 'github');
$completedFields = 0;
foreach ($profileFields as $field) {
    if (!empty($profile[$field])) {
        $completedFields++;
    }
}
$profileCompletion = (int) round(($completedFields / count($profileFields)) * 100);
$pageTitle = 'Dashboard | AlumniConnect';
$pageDescription = 'Your AlumniConnect community dashboard.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false">
                <span class="sr-only">Toggle dashboard menu</span>
                <span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span>
            </button>
            <div class="dashboard-topbar-copy">
                <span class="dashboard-kicker">AlumniConnect workspace</span>
                <strong><?php echo escape_html($profileName); ?></strong>
            </div>
            <a class="dashboard-account" href="profile.php">
                <span class="dashboard-avatar"><?php echo escape_html($profileInitial); ?></span>
                <span class="dashboard-account-details"><strong><?php echo escape_html($profileName); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span>
            </a>
        </header>

        <main class="dashboard-main">
            <section class="dashboard-welcome">
                <div>
                    <p class="eyebrow">Your dashboard</p>
                    <h1>Good to see you, <?php echo escape_html($profileName); ?>.</h1>
                    <p>Keep up with your community, discover opportunities and make your next connection count.</p>
                </div>
                <?php if ($currentUser['role'] === 'admin') : ?>
                    <a class="button button-secondary" href="admin/dashboard.php">Open admin panel <span aria-hidden="true">→</span></a>
                <?php else : ?>
                    <a class="button button-primary" href="profile.php">Complete your profile <span aria-hidden="true">→</span></a>
                <?php endif; ?>
            </section>

            <section class="dashboard-stats" aria-label="Community statistics">
                <article class="dashboard-stat-card"><span class="stat-icon stat-icon-blue">◎</span><div><strong><?php echo $dashboardData['stats']['students']; ?></strong><span>Active students</span></div></article>
                <article class="dashboard-stat-card"><span class="stat-icon stat-icon-purple">♧</span><div><strong><?php echo $dashboardData['stats']['alumni']; ?></strong><span>Active alumni</span></div></article>
                <article class="dashboard-stat-card"><span class="stat-icon stat-icon-gold">▣</span><div><strong><?php echo $dashboardData['stats']['jobs']; ?></strong><span>Available jobs</span></div></article>
                <article class="dashboard-stat-card"><span class="stat-icon stat-icon-green">◆</span><div><strong><?php echo $dashboardData['stats']['events']; ?></strong><span>Upcoming events</span></div></article>
            </section>

            <div class="dashboard-grid dashboard-grid-main">
                <section class="dashboard-panel profile-summary-panel">
                    <div class="panel-heading"><div><p class="panel-eyebrow">Your profile</p><h2>Profile summary</h2></div><a class="panel-link" href="profile.php">View profile →</a></div>
                    <div class="profile-summary">
                        <div class="profile-summary-avatar"><?php echo escape_html($profileInitial); ?></div>
                        <div><h3><?php echo escape_html($profileName); ?></h3><p><?php echo escape_html(ucfirst($currentUser['role'])); ?><?php if (!empty($profile['department'])) : ?> · <?php echo escape_html($profile['department']); ?><?php endif; ?></p><?php if (!empty($profile['company']) || !empty($profile['designation'])) : ?><small><?php echo escape_html(trim(($profile['designation'] ?? '') . ' ' . ($profile['company'] ?? ''))); ?></small><?php endif; ?></div>
                    </div>
                    <?php if ($currentUser['role'] !== 'admin' && $profileCompletion < 100) : ?>
                        <div class="completion-box"><div class="completion-heading"><strong>Complete your profile</strong><span><?php echo $profileCompletion; ?>%</span></div><div class="progress-track"><span style="width: <?php echo $profileCompletion; ?>%;"></span></div><p>Add more details to help your community discover you.</p></div>
                    <?php else : ?>
                        <div class="profile-ready"><span>✓</span> Your profile is ready for the community.</div>
                    <?php endif; ?>
                    <div class="profile-summary-meta"><span><strong><?php echo $dashboardData['connections']; ?></strong> connections</span><?php if ($dashboardData['pending_connections'] > 0) : ?><span><strong><?php echo $dashboardData['pending_connections']; ?></strong> pending request<?php echo $dashboardData['pending_connections'] === 1 ? '' : 's'; ?></span><?php endif; ?></div>
                </section>

                <section class="dashboard-panel members-panel">
                    <div class="panel-heading"><div><p class="panel-eyebrow">Community</p><h2>Recently joined</h2></div><a class="panel-link" href="alumni.php">View directory →</a></div>
                    <?php if (empty($dashboardData['members'])) : ?><p class="empty-state">No active members to show yet.</p><?php else : ?><div class="member-list"><?php foreach ($dashboardData['members'] as $member) : ?><div class="member-row"><?php $memberImage = !empty($member['profile_image']) ? basename($member['profile_image']) : ''; ?><?php if ($memberImage !== '') : ?><img class="member-avatar member-avatar-image" src="uploads/profiles/<?php echo escape_html($memberImage); ?>" alt="<?php echo escape_html($member['name']); ?> profile image"><?php else : ?><span class="member-avatar"><?php echo escape_html(strtoupper(substr($member['name'], 0, 1))); ?></span><?php endif; ?><div><strong><?php echo escape_html($member['name']); ?></strong><small><?php echo escape_html(ucfirst($member['role'])); ?><?php if (!empty($member['department'])) : ?> · <?php echo escape_html($member['department']); ?><?php endif; ?></small></div></div><?php endforeach; ?></div><?php endif; ?>
                </section>
            </div>

            <div class="dashboard-grid dashboard-grid-three">
                <section class="dashboard-panel">
                    <div class="panel-heading"><div><p class="panel-eyebrow">Opportunities</p><h2>Latest jobs</h2></div><a class="panel-link" href="jobs.php">See all →</a></div>
                    <?php if (empty($dashboardData['jobs'])) : ?><p class="empty-state">No job postings available yet.</p><?php else : ?><div class="compact-list"><?php foreach ($dashboardData['jobs'] as $job) : ?><a class="compact-row" href="jobs.php"><span class="compact-icon stat-icon-gold">▣</span><span><strong><?php echo escape_html($job['title']); ?></strong><small><?php echo escape_html($job['company'] ?: 'Company not specified'); ?> · <?php echo escape_html($job['location'] ?: 'Location not specified'); ?></small><em><?php echo escape_html($job['job_type'] ?: 'Opportunity'); ?> · <?php echo escape_html(date('M j, Y', strtotime($job['created_at']))); ?></em></span></a><?php endforeach; ?></div><?php endif; ?>
                </section>
                <section class="dashboard-panel">
                    <div class="panel-heading"><div><p class="panel-eyebrow">Community calendar</p><h2>Upcoming events</h2></div><a class="panel-link" href="events.php">See all →</a></div>
                    <?php if (empty($dashboardData['events'])) : ?><p class="empty-state">No upcoming events scheduled.</p><?php else : ?><div class="compact-list"><?php foreach ($dashboardData['events'] as $event) : ?><a class="compact-row" href="events.php"><span class="date-tile"><strong><?php echo escape_html(date('d', strtotime($event['event_date']))); ?></strong><small><?php echo escape_html(date('M', strtotime($event['event_date']))); ?></small></span><span><strong><?php echo escape_html($event['title']); ?></strong><small><?php echo escape_html(date('M j, Y · g:i A', strtotime($event['event_date']))); ?></small><em><?php echo escape_html($event['location'] ?: 'Location not specified'); ?> · <?php echo escape_html($event['creator_name']); ?></em></span></a><?php endforeach; ?></div><?php endif; ?>
                </section>
                <section class="dashboard-panel">
                    <div class="panel-heading"><div><p class="panel-eyebrow">Your updates</p><h2>Notifications</h2></div><a class="panel-link" href="notifications.php">View all →</a></div>
                    <?php if (empty($dashboardData['notifications'])) : ?><p class="empty-state">You have no notifications yet.</p><?php else : ?><div class="compact-list"><?php foreach ($dashboardData['notifications'] as $notification) : ?><div class="notification-row <?php echo (int) $notification['is_read'] === 0 ? 'is-unread' : ''; ?>"><span class="notification-dot"></span><span><strong><?php echo escape_html($notification['message']); ?></strong><small><?php echo escape_html($notification['type'] ?: 'Update'); ?> · <?php echo escape_html(date('M j, Y', strtotime($notification['created_at']))); ?></small></span></div><?php endforeach; ?></div><?php endif; ?>
                </section>
            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>