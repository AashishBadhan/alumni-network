<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$search = trim(isset($_GET['search']) ? $_GET['search'] : '');
$category = trim(isset($_GET['category']) ? $_GET['category'] : '');
$view = isset($_GET['view']) ? $_GET['view'] : '';
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = ($page !== false && $page !== null && $page > 0) ? $page : 1;
$perPage = 6;
$events = array();
$eventDetail = false;
$categories = array();
$totalEvents = 0;
$totalPages = 1;
$errors = isset($_SESSION['event_errors']) ? $_SESSION['event_errors'] : array();
$message = isset($_SESSION['event_success']) ? $_SESSION['event_success'] : '';
unset($_SESSION['event_errors'], $_SESSION['event_success']);

try {
    $accountStatement = $pdo->prepare('SELECT status FROM users WHERE id = :user_id LIMIT 1');
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: login.php');
        exit;
    }

    $categoryStatement = $pdo->query("SELECT DISTINCT category FROM events WHERE category IS NOT NULL AND category <> '' ORDER BY category");
    $categories = $categoryStatement->fetchAll(PDO::FETCH_COLUMN);

    $where = array('u.status = :status');
    $parameters = array(':status' => 'active');
    if ($search !== '') {
        $where[] = '(e.title LIKE :title_search OR e.location LIKE :location_search)';
        $parameters[':title_search'] = '%' . $search . '%';
        $parameters[':location_search'] = '%' . $search . '%';
    }
    if ($category !== '') {
        $where[] = 'e.category = :category';
        $parameters[':category'] = $category;
    }
    $whereSql = implode(' AND ', $where);

    if ($view !== '') {
        $eventId = filter_var($view, FILTER_VALIDATE_INT);
        if ($eventId !== false && $eventId > 0) {
            $detailStatement = $pdo->prepare(
                "SELECT e.*, u.name AS creator_name,
                    (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id) AS registration_count,
                    EXISTS(SELECT 1 FROM event_registrations er2 WHERE er2.event_id = e.id AND er2.user_id = :current_user) AS is_registered
                 FROM events e INNER JOIN users u ON u.id = e.user_id
                 WHERE e.id = :event_id AND u.status = 'active' LIMIT 1"
            );
            $detailStatement->execute(array(':event_id' => $eventId, ':current_user' => $currentUser['id']));
            $eventDetail = $detailStatement->fetch();
            if ($eventDetail !== false) {
                $attendeeStatement = $pdo->prepare(
                    "SELECT u.name, u.role, p.profile_image
                     FROM event_registrations er
                     INNER JOIN users u ON u.id = er.user_id
                     LEFT JOIN profiles p ON p.user_id = u.id
                     WHERE er.event_id = :event_id AND u.status = 'active'
                     ORDER BY er.registered_at ASC"
                );
                $attendeeStatement->execute(array(':event_id' => $eventId));
                $eventDetail['attendees'] = $attendeeStatement->fetchAll();
            }
        }
    }

    $countStatement = $pdo->prepare("SELECT COUNT(*) FROM events e INNER JOIN users u ON u.id = e.user_id WHERE " . $whereSql);
    $countStatement->execute($parameters);
    $totalEvents = (int) $countStatement->fetchColumn();
    $totalPages = max(1, (int) ceil($totalEvents / $perPage));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $perPage;
    $listStatement = $pdo->prepare(
        "SELECT e.id, e.title, e.description, e.event_date, e.location, e.category, e.user_id,
                u.name AS creator_name,
                (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id) AS registration_count,
                EXISTS(SELECT 1 FROM event_registrations er2 WHERE er2.event_id = e.id AND er2.user_id = :current_user) AS is_registered
         FROM events e INNER JOIN users u ON u.id = e.user_id
         WHERE " . $whereSql . "
         ORDER BY e.event_date ASC
         LIMIT :limit OFFSET :offset"
    );
    $listStatement->bindValue(':current_user', $currentUser['id'], PDO::PARAM_INT);
    foreach ($parameters as $key => $value) {
        $listStatement->bindValue($key, $value);
    }
    $listStatement->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $listStatement->bindValue(':offset', $offset, PDO::PARAM_INT);
    $listStatement->execute();
    $events = $listStatement->fetchAll();
} catch (PDOException $exception) {
    error_log('AlumniConnect events query failed. PDO error code: ' . $exception->getCode());
    $errors[] = 'Events are temporarily unavailable. Please try again later.';
}

$queryParameters = array_filter(array('search' => $search, 'category' => $category), function ($value) {
    return $value !== '';
});
$pageTitle = 'Events | AlumniConnect';
$pageDescription = 'Discover and join AlumniConnect community events.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button>
            <div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Events</strong></div>
            <a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a>
        </header>
        <main class="dashboard-main events-main">
            <?php if (!empty($errors)) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($errors as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
            <?php if ($message !== '') : ?><div class="form-alert form-alert-success" role="status"><?php echo escape_html($message); ?></div><?php endif; ?>
            <?php if ($eventDetail !== false) : ?>
                <a class="back-link" href="events.php">← Back to events</a>
                <section class="event-detail-card">
                    <div class="event-detail-heading"><div><span class="event-category"><?php echo escape_html($eventDetail['category'] ?: 'Community event'); ?></span><h1><?php echo escape_html($eventDetail['title']); ?></h1><p>Created by <?php echo escape_html($eventDetail['creator_name']); ?></p></div><span class="event-status <?php echo strtotime($eventDetail['event_date']) >= time() ? 'event-status-upcoming' : 'event-status-past'; ?>"><?php echo strtotime($eventDetail['event_date']) >= time() ? 'Upcoming' : 'Past'; ?></span></div>
                    <div class="event-detail-meta"><span>◆ <?php echo escape_html(date('M j, Y · g:i A', strtotime($eventDetail['event_date']))); ?></span><span>⌖ <?php echo escape_html($eventDetail['location'] ?: 'Location to be announced'); ?></span><span>◎ <?php echo (int) $eventDetail['registration_count']; ?> attendees</span></div>
                    <div class="event-detail-body"><h2>About this event</h2><p><?php echo $eventDetail['description'] !== '' ? nl2br(escape_html($eventDetail['description'])) : 'No description has been added yet.'; ?></p></div>
                    <div class="event-detail-actions">
                        <?php if (strtotime($eventDetail['event_date']) >= time()) : ?><form action="actions/event.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="<?php echo $eventDetail['is_registered'] ? 'cancel' : 'register'; ?>"><input type="hidden" name="event_id" value="<?php echo (int) $eventDetail['id']; ?>"><button class="button <?php echo $eventDetail['is_registered'] ? 'button-secondary' : 'button-primary'; ?>" type="submit"><?php echo $eventDetail['is_registered'] ? 'Cancel registration' : 'Register for event'; ?></button></form><?php endif; ?>
                        <?php if ((int) $eventDetail['user_id'] === (int) $currentUser['id'] || $currentUser['role'] === 'admin') : ?><a class="button button-secondary" href="edit-event.php?id=<?php echo (int) $eventDetail['id']; ?>">Edit event</a><form action="actions/event.php" method="post" onsubmit="return confirm('Delete this event?');"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="event_id" value="<?php echo (int) $eventDetail['id']; ?>"><button class="button button-danger" type="submit">Delete event</button></form><?php endif; ?>
                    </div>
                </section>
                <section class="dashboard-panel event-attendees"><div class="panel-heading"><div><p class="panel-eyebrow">Community attendance</p><h2>Registered attendees</h2></div></div><?php if (empty($eventDetail['attendees'])) : ?><p class="empty-state">No one has registered yet.</p><?php else : ?><div class="attendee-list"><?php foreach ($eventDetail['attendees'] as $attendee) : ?><div class="attendee-row"><span class="member-avatar"><?php echo escape_html(strtoupper(substr($attendee['name'], 0, 1))); ?></span><div><strong><?php echo escape_html($attendee['name']); ?></strong><small><?php echo escape_html(ucfirst($attendee['role'])); ?></small></div></div><?php endforeach; ?></div><?php endif; ?></section>
            <?php else : ?>
                <section class="events-heading"><div><p class="eyebrow">Gather, learn and connect</p><h1>Community events</h1><p>Find conversations and opportunities happening across your AlumniConnect community.</p></div><a class="button button-primary" href="create-event.php">Create event <span aria-hidden="true">→</span></a></section>
                <form class="event-filters" method="get" action="events.php"><div><label for="event-search">Search events</label><input id="event-search" type="search" name="search" value="<?php echo escape_html($search); ?>" placeholder="Title or location"></div><div><label for="event-category">Category</label><select id="event-category" name="category"><option value="">All categories</option><?php foreach ($categories as $option) : ?><option value="<?php echo escape_html($option); ?>" <?php echo $category === $option ? 'selected' : ''; ?>><?php echo escape_html($option); ?></option><?php endforeach; ?></select></div><button class="button button-primary" type="submit">Search</button><?php if (!empty($queryParameters)) : ?><a class="event-reset" href="events.php">Clear filters</a><?php endif; ?></form>
                <?php if (empty($events)) : ?><section class="directory-empty"><span class="directory-empty-icon">◆</span><h2>No events found</h2><p>Try a different search, or create the first event for your community.</p></section><?php else : ?><section class="event-card-grid" aria-label="Community events"><?php foreach ($events as $event) : $isUpcoming = strtotime($event['event_date']) >= time(); ?><article class="event-card"><div class="event-card-heading"><span class="event-category"><?php echo escape_html($event['category'] ?: 'Community event'); ?></span><span class="event-status <?php echo $isUpcoming ? 'event-status-upcoming' : 'event-status-past'; ?>"><?php echo $isUpcoming ? 'Upcoming' : 'Past'; ?></span></div><h2><?php echo escape_html($event['title']); ?></h2><p class="event-card-description"><?php echo escape_html(strlen($event['description']) > 130 ? substr($event['description'], 0, 127) . '...' : ($event['description'] ?: 'No description provided.')); ?></p><div class="event-card-meta"><span>◆ <?php echo escape_html(date('M j, Y · g:i A', strtotime($event['event_date']))); ?></span><span>⌖ <?php echo escape_html($event['location'] ?: 'Location to be announced'); ?></span><span>◎ <?php echo (int) $event['registration_count']; ?> registered</span></div><div class="event-card-footer"><small>By <?php echo escape_html($event['creator_name']); ?></small><a class="button button-secondary" href="events.php?view=<?php echo (int) $event['id']; ?>">View details</a></div></article><?php endforeach; ?></section><?php if ($totalPages > 1) : ?><nav class="pagination" aria-label="Event pagination"><?php if ($page > 1) : ?><a class="pagination-link" href="events.php?<?php echo http_build_query(array_merge($queryParameters, array('page' => $page - 1))); ?>">← Previous</a><?php else : ?><span class="pagination-link is-disabled">← Previous</span><?php endif; ?><span class="pagination-status">Page <?php echo $page; ?> of <?php echo $totalPages; ?></span><?php if ($page < $totalPages) : ?><a class="pagination-link" href="events.php?<?php echo http_build_query(array_merge($queryParameters, array('page' => $page + 1))); ?>">Next →</a><?php else : ?><span class="pagination-link is-disabled">Next →</span><?php endif; ?></nav><?php endif; ?><?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>