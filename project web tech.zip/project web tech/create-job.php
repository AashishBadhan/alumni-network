<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';
$currentUser = get_current_user_info();
$pageTitle = 'Post a Job | AlumniConnect';
$pageDescription = 'Share a career opportunity with the AlumniConnect community.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar"><button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button><div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Post a job</strong></div><a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a></header>
        <main class="dashboard-main job-form-main"><a class="back-link" href="jobs.php">← Back to jobs</a><section class="directory-heading"><div><p class="eyebrow">Share an opportunity</p><h1>Post a job</h1><p>Help students and alumni discover their next career step.</p></div></section><?php if (!empty($_SESSION['job_errors'])) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($_SESSION['job_errors'] as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php unset($_SESSION['job_errors']); endif; ?><?php require __DIR__ . '/job-form.php'; ?></main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>