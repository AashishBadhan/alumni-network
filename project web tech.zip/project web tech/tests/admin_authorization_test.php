<?php

require_once __DIR__ . '/../includes/admin_permissions.php';

function test_result($condition, $description)
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: " . $description . PHP_EOL);
        exit(1);
    }

    echo "PASS: " . $description . PHP_EOL;
}

$primaryAdmin = array('id' => 2, 'role' => 'admin', 'status' => 'active');
$normalAdmin = array('id' => 10, 'role' => 'admin', 'status' => 'active');
$student = array('id' => 11, 'role' => 'student', 'status' => 'active');
$otherAdmin = array('id' => 12, 'role' => 'admin', 'status' => 'active');

test_result(
    !can_change_admin_role($normalAdmin, $primaryAdmin, 'student'),
    'normal admin cannot demote the primary admin'
);
test_result(
    !can_change_admin_status($normalAdmin, $primaryAdmin, 'blocked'),
    'normal admin cannot deactivate the primary admin'
);
test_result(
    !can_delete_admin_user($normalAdmin, $primaryAdmin),
    'normal admin cannot delete the primary admin'
);
test_result(
    !can_change_admin_role($normalAdmin, $normalAdmin, 'student'),
    'admin cannot demote the admin account used for the request'
);
test_result(
    !can_change_admin_role($normalAdmin, $otherAdmin, 'student'),
    'normal admin cannot change another admin role'
);
test_result(
    !can_change_admin_status($normalAdmin, $otherAdmin, 'blocked'),
    'normal admin cannot deactivate another admin'
);
test_result(
    !can_delete_admin_user($normalAdmin, $otherAdmin),
    'normal admin cannot delete another admin'
);
test_result(
    can_change_admin_role($primaryAdmin, $student, 'admin'),
    'primary admin can promote a student'
);
test_result(
    can_change_admin_role($primaryAdmin, $otherAdmin, 'student'),
    'primary admin can demote another admin'
);
test_result(
    can_delete_admin_user($primaryAdmin, $otherAdmin),
    'primary admin can delete another admin'
);
