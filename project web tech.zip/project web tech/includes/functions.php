<?php
require_once __DIR__ . '/db.php';

/**
 * Returns the number of unread notifications for one user.
 */
function get_unread_notification_count($pdo, $userId)
{
    $statement = $pdo->prepare(
        'SELECT COUNT(*) FROM notifications
         WHERE user_id = :user_id AND is_read = 0'
    );
    $statement->execute(array(':user_id' => $userId));
    return (int) $statement->fetchColumn();
}

/**
 * Returns a simple icon for a notification type.
 */
function get_notification_icon($type)
{
    $icons = array(
        'connection_request' => '↗',
        'connection_accepted' => '✓',
        'event_registration' => '◆',
        'event_updated' => '✎',
        'event_deleted' => '×',
    );

    return isset($icons[$type]) ? $icons[$type] : '◌';
}