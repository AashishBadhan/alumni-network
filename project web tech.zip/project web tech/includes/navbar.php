<?php
require_once __DIR__ . '/auth.php';
start_secure_session();
$navigationUser = get_current_user_info();
$unreadNotificationCount = 0;
if ($navigationUser !== null) {
    require_once __DIR__ . '/db.php';
    try {
        require_once __DIR__ . '/functions.php';
        $unreadNotificationCount = get_unread_notification_count($pdo, $navigationUser['id']);
    } catch (PDOException $exception) {
        error_log('AlumniConnect navbar notification count failed. PDO error code: ' . $exception->getCode());
    }
}
?>
<header class="site-header">
    <div class="container navbar">
        <a class="brand" href="index.php" aria-label="AlumniConnect home">
            <span class="brand-mark">A</span>
            <span class="brand-name">Alumni<span>Connect</span></span>
        </a>

        <button class="menu-toggle" type="button" aria-controls="primary-navigation" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="menu-bar"></span>
            <span class="menu-bar"></span>
            <span class="menu-bar"></span>
        </button>

        <nav class="primary-navigation" id="primary-navigation" aria-label="Primary navigation">
            <a href="index.php">Home</a>
            <a href="index.php#features">Features</a>
            <a href="index.php#how-it-works">How It Works</a>
            <?php if ($navigationUser !== null) : ?>
                <a href="dashboard.php">Dashboard</a>
                <a class="nav-notification-link" href="notifications.php">Notifications<?php if ($unreadNotificationCount > 0) : ?><span class="notification-count" aria-label="<?php echo $unreadNotificationCount; ?> unread notifications"><?php echo $unreadNotificationCount > 99 ? '99+' : $unreadNotificationCount; ?></span><?php endif; ?></a>
                <a class="nav-register" href="logout.php">Logout</a>
            <?php else : ?>
                <a href="login.php">Login</a>
                <a class="nav-register" href="register.php">Register <span aria-hidden="true">→</span></a>
            <?php endif; ?>
        </nav>
    </div>
</header>