<?php

define('ALUMNICONNECT_PRIMARY_ADMIN_ID', 2);

function is_primary_admin($adminUser)
{
    return (int) $adminUser['id'] === ALUMNICONNECT_PRIMARY_ADMIN_ID;
}

function can_change_admin_role($adminUser, $targetUser, $newRole)
{
    if ((int) $targetUser['id'] === (int) $adminUser['id']) {
        return false;
    }

    if ((int) $targetUser['id'] === ALUMNICONNECT_PRIMARY_ADMIN_ID) {
        return false;
    }

    if ((int) $adminUser['id'] === ALUMNICONNECT_PRIMARY_ADMIN_ID) {
        return true;
    }

    return $targetUser['role'] !== 'admin' && $newRole !== 'admin';
}

function can_change_admin_status($adminUser, $targetUser, $newStatus)
{
    if ((int) $targetUser['id'] === (int) $adminUser['id']) {
        return false;
    }

    if ((int) $targetUser['id'] === ALUMNICONNECT_PRIMARY_ADMIN_ID) {
        return false;
    }

    return $targetUser['role'] !== 'admin' || is_primary_admin($adminUser);
}

function can_delete_admin_user($adminUser, $targetUser)
{
    if ((int) $targetUser['id'] === (int) $adminUser['id']) {
        return false;
    }

    if ((int) $targetUser['id'] === ALUMNICONNECT_PRIMARY_ADMIN_ID) {
        return false;
    }

    return $targetUser['role'] !== 'admin' || is_primary_admin($adminUser);
}
