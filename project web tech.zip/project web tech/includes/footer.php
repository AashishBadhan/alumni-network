<footer class="site-footer">
    <div class="container footer-grid">
        <div class="footer-brand">
            <a class="brand brand-footer" href="<?php echo isset($sitePrefix) ? $sitePrefix : ''; ?>index.php">
                <span class="brand-mark">A</span>
                <span class="brand-name">Alumni<span>Connect</span></span>
            </a>
            <p>Building stronger connections between students, alumni and the opportunities ahead.</p>
        </div>
        <div class="footer-links">
            <h3>Explore</h3>
            <a href="<?php echo isset($sitePrefix) ? $sitePrefix : ''; ?>index.php">Home</a>
            <a href="<?php echo isset($sitePrefix) ? $sitePrefix : ''; ?>index.php#features">Features</a>
            <a href="<?php echo isset($sitePrefix) ? $sitePrefix : ''; ?>index.php#how-it-works">How It Works</a>
        </div>
        <div class="footer-links">
            <h3>Get started</h3>
            <a href="<?php echo isset($sitePrefix) ? $sitePrefix : ''; ?>login.php">Login</a>
            <a href="<?php echo isset($sitePrefix) ? $sitePrefix : ''; ?>register.php">Register</a>
        </div>
    </div>
    <div class="container footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> AlumniConnect. Built for meaningful connections.</p>
    </div>
</footer>
<script src="<?php echo isset($sitePrefix) ? $sitePrefix : ''; ?>assets/js/script.js"></script>
</body>
</html>