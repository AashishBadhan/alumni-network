<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$sidebarUnreadCount = 0;
if (isset($pdo) && isset($currentUser)) {
    try {
        require_once __DIR__ . '/functions.php';
        $sidebarUnreadCount = get_unread_notification_count($pdo, $currentUser['id']);
    } catch (PDOException $exception) {
        error_log('AlumniConnect sidebar notification count failed. PDO error code: ' . $exception->getCode());
    }
}
?>
<aside class="dashboard-sidebar" id="dashboard-sidebar" aria-label="Dashboard navigation">
    <a class="sidebar-brand" href="dashboard.php">
        <span class="brand-mark">A</span>
        <span class="brand-name">Alumni<span>Connect</span></span>
    </a>
    <nav class="sidebar-navigation">
        <a class="<?php echo $currentPage === 'dashboard.php' ? 'is-active' : ''; ?>" href="dashboard.php"><span class="sidebar-icon">▦</span>Dashboard</a>
        <a class="<?php echo $currentPage === 'profile.php' ? 'is-active' : ''; ?>" href="profile.php"><span class="sidebar-icon">◎</span>My Profile</a>
        <a class="<?php echo $currentPage === 'alumni.php' ? 'is-active' : ''; ?>" href="alumni.php"><span class="sidebar-icon">♧</span>Alumni Directory</a>
        <a class="<?php echo $currentPage === 'events.php' ? 'is-active' : ''; ?>" href="events.php"><span class="sidebar-icon">◆</span>Events</a>
        <a class="<?php echo $currentPage === 'jobs.php' ? 'is-active' : ''; ?>" href="jobs.php"><span class="sidebar-icon">▣</span>Jobs</a>
        <a class="<?php echo $currentPage === 'connections.php' ? 'is-active' : ''; ?>" href="connections.php"><span class="sidebar-icon">↗</span>Connections</a>
        <a class="<?php echo $currentPage === 'notifications.php' ? 'is-active' : ''; ?>" href="notifications.php"><span class="sidebar-icon">◌</span>Notifications<?php if ($sidebarUnreadCount > 0) : ?><span class="sidebar-notification-count"><?php echo $sidebarUnreadCount > 99 ? '99+' : $sidebarUnreadCount; ?></span><?php endif; ?></a>
    </nav>
    <a class="sidebar-logout" href="logout.php"><span class="sidebar-icon">↪</span>Sign out</a>
</aside>