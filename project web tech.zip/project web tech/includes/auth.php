<?php
/**
 * Shared authentication and session helpers.
 */

function start_secure_session()
{
    if (session_status() === PHP_SESSION_NONE) {
        $isSecure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

        session_set_cookie_params(array(
            'lifetime' => 0,
            'path' => '/',
            'secure' => $isSecure,
            'httponly' => true,
            'samesite' => 'Lax',
        ));

        session_start();
    }
}

function is_user_logged_in()
{
    start_secure_session();
    return isset($_SESSION['user_id']) && is_int($_SESSION['user_id']);
}

function get_current_user_info()
{
    start_secure_session();

    if (!is_user_logged_in()) {
        return null;
    }

    return array(
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'],
        'role' => $_SESSION['user_role'],
    );
}

function current_user_has_role($role)
{
    $user = get_current_user_info();
    return $user !== null && $user['role'] === $role;
}

function require_authentication()
{
    if (!is_user_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function require_role($role)
{
    require_authentication();

    if (!current_user_has_role($role)) {
        http_response_code(403);
        exit('You do not have permission to access this page.');
    }
}

function get_csrf_token()
{
    start_secure_session();

    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token)
{
    start_secure_session();
    return is_string($token)
        && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

function escape_html($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}