<?php
/*
 * Creates the shared PDO connection for AlumniConnect.
 * XAMPP defaults can be overridden with environment variables.
 */

if (!isset($pdo)) {
    $productionConfig = array();
    $productionConfigPath = __DIR__ . '/production_config.php';
    if (is_file($productionConfigPath)) {
        $loadedConfig = require $productionConfigPath;
        if (is_array($loadedConfig)) {
            $productionConfig = $loadedConfig;
        }
    }

    $dbHost = getenv('ALUMNICONNECT_DB_HOST');
    $dbPort = getenv('ALUMNICONNECT_DB_PORT');
    $dbName = getenv('ALUMNICONNECT_DB_NAME');
    $dbUser = getenv('ALUMNICONNECT_DB_USER');
    $dbPassword = getenv('ALUMNICONNECT_DB_PASSWORD');

    $dbHost = ($dbHost !== false && $dbHost !== '')
        ? $dbHost
        : (isset($productionConfig['host']) ? $productionConfig['host'] : 'localhost');
    $dbPort = ($dbPort !== false && $dbPort !== '')
        ? $dbPort
        : (isset($productionConfig['port']) ? $productionConfig['port'] : '3306');
    $dbName = ($dbName !== false && $dbName !== '')
        ? $dbName
        : (isset($productionConfig['name']) ? $productionConfig['name'] : 'alumni_network');
    $dbUser = ($dbUser !== false && $dbUser !== '')
        ? $dbUser
        : (isset($productionConfig['user']) ? $productionConfig['user'] : 'root');
    $dbPassword = ($dbPassword !== false)
        ? $dbPassword
        : (isset($productionConfig['password']) ? $productionConfig['password'] : '');

    $dsn = 'mysql:host=' . $dbHost
        . ';port=' . $dbPort
        . ';dbname=' . $dbName
        . ';charset=utf8mb4';

    try {
        $pdo = new PDO($dsn, $dbUser, $dbPassword, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ));
    } catch (PDOException $exception) {
        error_log(
            'AlumniConnect database connection failed. PDO error code: '
            . $exception->getCode()
        );
        $pdo = null;
        exit('Database connection unavailable. Please try again later.');
    }
}