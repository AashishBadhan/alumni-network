<?php
$pageTitle = isset($pageTitle) ? $pageTitle : 'AlumniConnect | College Alumni Network';
$pageDescription = isset($pageDescription)
    ? $pageDescription
    : 'AlumniConnect helps students and alumni build meaningful professional connections.';
$bodyClass = isset($bodyClass) ? $bodyClass : '';
$assetPrefix = isset($assetPrefix) ? $assetPrefix : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8'); ?>">
    <title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($assetPrefix, ENT_QUOTES, 'UTF-8'); ?>assets/css/style.css">
</head>
<body class="<?php echo htmlspecialchars($bodyClass, ENT_QUOTES, 'UTF-8'); ?>">