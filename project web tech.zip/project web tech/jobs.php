<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$search = trim(isset($_GET['search']) ? $_GET['search'] : '');
$location = trim(isset($_GET['location']) ? $_GET['location'] : '');
$jobType = trim(isset($_GET['job_type']) ? $_GET['job_type'] : '');
$experience = trim(isset($_GET['experience']) ? $_GET['experience'] : '');
$view = isset($_GET['view']) ? filter_var($_GET['view'], FILTER_VALIDATE_INT) : false;
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = ($page !== false && $page !== null && $page > 0) ? $page : 1;
$perPage = 6;
$jobs = array();
$jobDetail = false;
$locations = array();
$jobTypes = array();
$experiences = array();
$totalJobs = 0;
$totalPages = 1;
$errors = isset($_SESSION['job_errors']) ? $_SESSION['job_errors'] : array();
$message = isset($_SESSION['job_success']) ? $_SESSION['job_success'] : '';
unset($_SESSION['job_errors'], $_SESSION['job_success']);

try {
    $accountStatement = $pdo->prepare('SELECT status FROM users WHERE id = :user_id LIMIT 1');
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: login.php');
        exit;
    }

    $optionsStatement = $pdo->query(
        'SELECT DISTINCT location, job_type, experience
         FROM jobs
         WHERE location IS NOT NULL OR job_type IS NOT NULL OR experience IS NOT NULL
         ORDER BY location, job_type, experience'
    );
    foreach ($optionsStatement->fetchAll() as $option) {
        if (!empty($option['location']) && !in_array($option['location'], $locations, true)) {
            $locations[] = $option['location'];
        }
        if (!empty($option['job_type']) && !in_array($option['job_type'], $jobTypes, true)) {
            $jobTypes[] = $option['job_type'];
        }
        if (!empty($option['experience']) && !in_array($option['experience'], $experiences, true)) {
            $experiences[] = $option['experience'];
        }
    }
    sort($locations);
    sort($jobTypes);
    sort($experiences);

    if ($view !== false && $view > 0) {
        $detailStatement = $pdo->prepare(
            "SELECT j.*, u.name AS creator_name
             FROM jobs j INNER JOIN users u ON u.id = j.user_id
             WHERE j.id = :job_id AND u.status = 'active'
             LIMIT 1"
        );
        $detailStatement->execute(array(':job_id' => $view));
        $jobDetail = $detailStatement->fetch();
    }

    $where = array('u.status = :status');
    $parameters = array(':status' => 'active');
    if ($search !== '') {
        $where[] = '(j.title LIKE :title_search OR j.company LIKE :company_search)';
        $parameters[':title_search'] = '%' . $search . '%';
        $parameters[':company_search'] = '%' . $search . '%';
    }
    if ($location !== '') {
        $where[] = 'j.location = :location';
        $parameters[':location'] = $location;
    }
    if ($jobType !== '') {
        $where[] = 'j.job_type = :job_type';
        $parameters[':job_type'] = $jobType;
    }
    if ($experience !== '') {
        $where[] = 'j.experience = :experience';
        $parameters[':experience'] = $experience;
    }
    $whereSql = implode(' AND ', $where);

    $countStatement = $pdo->prepare('SELECT COUNT(*) FROM jobs j INNER JOIN users u ON u.id = j.user_id WHERE ' . $whereSql);
    $countStatement->execute($parameters);
    $totalJobs = (int) $countStatement->fetchColumn();
    $totalPages = max(1, (int) ceil($totalJobs / $perPage));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $perPage;

    $listStatement = $pdo->prepare(
        'SELECT j.id, j.title, j.company, j.location, j.job_type, j.experience,
                j.salary, j.description, j.skills, j.created_at, j.user_id,
                u.name AS creator_name
         FROM jobs j INNER JOIN users u ON u.id = j.user_id
         WHERE ' . $whereSql . '
         ORDER BY j.created_at DESC
         LIMIT :limit OFFSET :offset'
    );
    foreach ($parameters as $key => $value) {
        $listStatement->bindValue($key, $value);
    }
    $listStatement->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $listStatement->bindValue(':offset', $offset, PDO::PARAM_INT);
    $listStatement->execute();
    $jobs = $listStatement->fetchAll();
} catch (PDOException $exception) {
    error_log('AlumniConnect jobs query failed. PDO error code: ' . $exception->getCode());
    $errors[] = 'Jobs are temporarily unavailable. Please try again later.';
}

$queryParameters = array_filter(array(
    'search' => $search,
    'location' => $location,
    'job_type' => $jobType,
    'experience' => $experience,
), function ($value) {
    return $value !== '';
});

$pageTitle = 'Jobs | AlumniConnect';
$pageDescription = 'Discover career opportunities shared by the AlumniConnect community.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar"><button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button><div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Jobs</strong></div><a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a></header>
        <main class="dashboard-main jobs-main">
            <?php if (!empty($errors)) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($errors as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
            <?php if ($message !== '') : ?><div class="form-alert form-alert-success" role="status"><?php echo escape_html($message); ?></div><?php endif; ?>
            <?php if ($jobDetail !== false) : ?>
                <?php $safeApplyLink = !empty($jobDetail['apply_link']) && filter_var($jobDetail['apply_link'], FILTER_VALIDATE_URL) && in_array(strtolower((string) parse_url($jobDetail['apply_link'], PHP_URL_SCHEME)), array('http', 'https'), true) ? $jobDetail['apply_link'] : ''; ?>
                <a class="back-link" href="jobs.php">← Back to jobs</a>
                <section class="job-detail-card"><div class="job-detail-heading"><div><span class="job-type-badge"><?php echo escape_html($jobDetail['job_type'] ?: 'Opportunity'); ?></span><h1><?php echo escape_html($jobDetail['title']); ?></h1><p><?php echo escape_html($jobDetail['company'] ?: 'Company not specified'); ?> · Posted by <?php echo escape_html($jobDetail['creator_name']); ?></p></div></div><div class="job-detail-meta"><span>⌖ <?php echo escape_html($jobDetail['location'] ?: 'Location not specified'); ?></span><span>◷ <?php echo escape_html($jobDetail['experience'] ?: 'Experience not specified'); ?></span><span>◎ <?php echo escape_html($jobDetail['salary'] ?: 'Salary not specified'); ?></span><span>Posted <?php echo escape_html(date('M j, Y', strtotime($jobDetail['created_at']))); ?></span></div><div class="job-detail-body"><h2>About this opportunity</h2><p><?php echo $jobDetail['description'] !== '' ? nl2br(escape_html($jobDetail['description'])) : 'No description has been added yet.'; ?></p><?php if (!empty($jobDetail['skills'])) : ?><h3>Required skills</h3><p><?php echo nl2br(escape_html($jobDetail['skills'])); ?></p><?php endif; ?></div><div class="job-detail-actions"><?php if ($safeApplyLink !== '') : ?><a class="button button-primary" href="<?php echo escape_html($safeApplyLink); ?>" target="_blank" rel="noopener noreferrer">Apply now <span aria-hidden="true">↗</span></a><?php endif; ?><?php if ((int) $jobDetail['user_id'] === (int) $currentUser['id'] || $currentUser['role'] === 'admin') : ?><a class="button button-secondary" href="edit-job.php?id=<?php echo (int) $jobDetail['id']; ?>">Edit job</a><form action="actions/job.php" method="post" onsubmit="return confirm('Delete this job post?');"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="job_id" value="<?php echo (int) $jobDetail['id']; ?>"><button class="button button-danger" type="submit">Delete job</button></form><?php endif; ?></div></section>
            <?php else : ?>
                <section class="jobs-heading"><div><p class="eyebrow">Find your next opportunity</p><h1>Career opportunities</h1><p>Explore roles shared by students, alumni and the wider community.</p></div><a class="button button-primary" href="create-job.php">Post a job <span aria-hidden="true">→</span></a></section>
                <form class="job-filters" method="get" action="jobs.php"><div><label for="job-search">Search jobs</label><input id="job-search" type="search" name="search" value="<?php echo escape_html($search); ?>" placeholder="Job title or company"></div><div><label for="job-location">Location</label><select id="job-location" name="location"><option value="">All locations</option><?php foreach ($locations as $option) : ?><option value="<?php echo escape_html($option); ?>" <?php echo $location === $option ? 'selected' : ''; ?>><?php echo escape_html($option); ?></option><?php endforeach; ?></select></div><div><label for="job-type">Job type</label><select id="job-type" name="job_type"><option value="">All job types</option><?php foreach ($jobTypes as $option) : ?><option value="<?php echo escape_html($option); ?>" <?php echo $jobType === $option ? 'selected' : ''; ?>><?php echo escape_html($option); ?></option><?php endforeach; ?></select></div><div><label for="job-experience">Experience</label><select id="job-experience" name="experience"><option value="">All experience levels</option><?php foreach ($experiences as $option) : ?><option value="<?php echo escape_html($option); ?>" <?php echo $experience === $option ? 'selected' : ''; ?>><?php echo escape_html($option); ?></option><?php endforeach; ?></select></div><button class="button button-primary" type="submit">Search</button><?php if (!empty($queryParameters)) : ?><a class="job-reset" href="jobs.php">Clear filters</a><?php endif; ?></form>
                <?php if (empty($jobs)) : ?><section class="directory-empty"><span class="directory-empty-icon">▣</span><h2>No jobs found</h2><p>Try a different search, or share the first opportunity with your community.</p></section><?php else : ?><section class="job-card-grid" aria-label="Job opportunities"><?php foreach ($jobs as $job) : ?><article class="job-card"><div class="job-card-heading"><span class="job-type-badge"><?php echo escape_html($job['job_type'] ?: 'Opportunity'); ?></span><span class="job-posted"><?php echo escape_html(date('M j, Y', strtotime($job['created_at']))); ?></span></div><h2><?php echo escape_html($job['title']); ?></h2><p class="job-company"><?php echo escape_html($job['company'] ?: 'Company not specified'); ?></p><p class="job-description"><?php echo escape_html(strlen($job['description']) > 130 ? substr($job['description'], 0, 127) . '...' : ($job['description'] ?: 'No description provided.')); ?></p><div class="job-card-meta"><span>⌖ <?php echo escape_html($job['location'] ?: 'Location not specified'); ?></span><span>◷ <?php echo escape_html($job['experience'] ?: 'Experience not specified'); ?></span><span>◎ <?php echo escape_html($job['salary'] ?: 'Salary not specified'); ?></span></div><div class="job-card-footer"><small>By <?php echo escape_html($job['creator_name']); ?></small><a class="button button-secondary" href="jobs.php?view=<?php echo (int) $job['id']; ?>">View job</a></div></article><?php endforeach; ?></section><?php if ($totalPages > 1) : ?><nav class="pagination" aria-label="Jobs pagination"><?php if ($page > 1) : ?><a class="pagination-link" href="jobs.php?<?php echo http_build_query(array_merge($queryParameters, array('page' => $page - 1))); ?>">← Previous</a><?php else : ?><span class="pagination-link is-disabled">← Previous</span><?php endif; ?><span class="pagination-status">Page <?php echo $page; ?> of <?php echo $totalPages; ?></span><?php if ($page < $totalPages) : ?><a class="pagination-link" href="jobs.php?<?php echo http_build_query(array_merge($queryParameters, array('page' => $page + 1))); ?>">Next →</a><?php else : ?><span class="pagination-link is-disabled">Next →</span><?php endif; ?></nav><?php endif; ?><?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>