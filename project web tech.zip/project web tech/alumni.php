<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$search = trim(isset($_GET['search']) ? $_GET['search'] : '');
$role = isset($_GET['role']) ? $_GET['role'] : '';
$department = trim(isset($_GET['department']) ? $_GET['department'] : '');
$graduationYear = trim(isset($_GET['graduation_year']) ? $_GET['graduation_year'] : '');
$company = trim(isset($_GET['company']) ? $_GET['company'] : '');
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = ($page !== false && $page !== null && $page > 0) ? $page : 1;
$perPage = 9;

if (!in_array($role, array('', 'student', 'alumni'), true)) {
    $role = '';
}
if ($graduationYear !== '' && !preg_match('/^\d{4}$/', $graduationYear)) {
    $graduationYear = '';
}

$where = array('u.status = :member_status', "u.role IN ('student', 'alumni')");
$parameters = array(':member_status' => 'active');

if ($search !== '') {
    $where[] = '(u.name LIKE :search_name OR p.company LIKE :search_company OR p.designation LIKE :search_designation)';
    $searchValue = '%' . $search . '%';
    $parameters[':search_name'] = $searchValue;
    $parameters[':search_company'] = $searchValue;
    $parameters[':search_designation'] = $searchValue;
}
if ($role !== '') {
    $where[] = 'u.role = :role';
    $parameters[':role'] = $role;
}
if ($department !== '') {
    $where[] = 'p.department = :department';
    $parameters[':department'] = $department;
}
if ($graduationYear !== '') {
    $where[] = 'p.graduation_year = :graduation_year';
    $parameters[':graduation_year'] = $graduationYear;
}
if ($company !== '') {
    $where[] = 'p.company = :company';
    $parameters[':company'] = $company;
}

$members = array();
$totalMembers = 0;
$departments = array();
$years = array();
$companies = array();

try {
    $activeAccountStatement = $pdo->prepare('SELECT status FROM users WHERE id = :user_id LIMIT 1');
    $activeAccountStatement->execute(array(':user_id' => $currentUser['id']));
    $activeAccount = $activeAccountStatement->fetch();
    if ($activeAccount === false || $activeAccount['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: login.php');
        exit;
    }

    $optionsStatement = $pdo->query(
        'SELECT DISTINCT department, graduation_year, company
         FROM profiles
         WHERE department IS NOT NULL OR graduation_year IS NOT NULL OR company IS NOT NULL
         ORDER BY department, graduation_year, company'
    );
    foreach ($optionsStatement->fetchAll() as $option) {
        if (!empty($option['department']) && !in_array($option['department'], $departments, true)) {
            $departments[] = $option['department'];
        }
        if (!empty($option['graduation_year']) && !in_array((string) $option['graduation_year'], $years, true)) {
            $years[] = (string) $option['graduation_year'];
        }
        if (!empty($option['company']) && !in_array($option['company'], $companies, true)) {
            $companies[] = $option['company'];
        }
    }
    sort($departments);
    rsort($years);
    sort($companies);

    $whereSql = implode(' AND ', $where);
    $countStatement = $pdo->prepare(
        'SELECT COUNT(*)
         FROM users u
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE ' . $whereSql
    );
    $countStatement->execute($parameters);
    $totalMembers = (int) $countStatement->fetchColumn();
    $totalPages = max(1, (int) ceil($totalMembers / $perPage));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $perPage;

    $memberStatement = $pdo->prepare(
        'SELECT u.id, u.name, u.role, p.department, p.graduation_year, p.company,
                p.designation, p.profile_image
         FROM users u
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE ' . $whereSql . '
         ORDER BY u.created_at DESC
         LIMIT :limit OFFSET :offset'
    );
    foreach ($parameters as $key => $value) {
        $memberStatement->bindValue($key, $value);
    }
    $memberStatement->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $memberStatement->bindValue(':offset', $offset, PDO::PARAM_INT);
    $memberStatement->execute();
    $members = $memberStatement->fetchAll();
} catch (PDOException $exception) {
    error_log('AlumniConnect directory query failed. PDO error code: ' . $exception->getCode());
    $totalPages = 1;
}

$queryParameters = array(
    'search' => $search,
    'role' => $role,
    'department' => $department,
    'graduation_year' => $graduationYear,
    'company' => $company,
);
$queryParameters = array_filter($queryParameters, function ($value) {
    return $value !== '';
});

$pageTitle = 'Member Directory | AlumniConnect';
$pageDescription = 'Discover active students and alumni in the AlumniConnect member directory.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false">
                <span class="sr-only">Toggle dashboard menu</span>
                <span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span>
            </button>
            <div class="dashboard-topbar-copy">
                <span class="dashboard-kicker">AlumniConnect workspace</span>
                <strong>Member directory</strong>
            </div>
            <a class="dashboard-account" href="profile.php">
                <span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span>
                <span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span>
            </a>
        </header>

        <main class="dashboard-main directory-main">
            <section class="directory-heading">
                <div><p class="eyebrow">Find your community</p><h1>Alumni and student directory</h1><p>Discover people, experiences and paths that connect with your own.</p></div>
                <span class="directory-count"><?php echo $totalMembers; ?> member<?php echo $totalMembers === 1 ? '' : 's'; ?></span>
            </section>

            <form class="directory-filters" method="get" action="alumni.php">
                <div class="directory-search"><label for="directory-search">Search members</label><input id="directory-search" type="search" name="search" value="<?php echo escape_html($search); ?>" placeholder="Name, company or designation"></div>
                <div class="directory-filter-field"><label for="role-filter">Role</label><select id="role-filter" name="role"><option value="">All roles</option><option value="student" <?php echo $role === 'student' ? 'selected' : ''; ?>>Student</option><option value="alumni" <?php echo $role === 'alumni' ? 'selected' : ''; ?>>Alumni</option></select></div>
                <div class="directory-filter-field"><label for="department-filter">Department</label><select id="department-filter" name="department"><option value="">All departments</option><?php foreach ($departments as $option) : ?><option value="<?php echo escape_html($option); ?>" <?php echo $department === $option ? 'selected' : ''; ?>><?php echo escape_html($option); ?></option><?php endforeach; ?></select></div>
                <div class="directory-filter-field"><label for="year-filter">Graduation year</label><select id="year-filter" name="graduation_year"><option value="">All years</option><?php foreach ($years as $option) : ?><option value="<?php echo escape_html($option); ?>" <?php echo $graduationYear === $option ? 'selected' : ''; ?>><?php echo escape_html($option); ?></option><?php endforeach; ?></select></div>
                <div class="directory-filter-field"><label for="company-filter">Company</label><select id="company-filter" name="company"><option value="">All companies</option><?php foreach ($companies as $option) : ?><option value="<?php echo escape_html($option); ?>" <?php echo $company === $option ? 'selected' : ''; ?>><?php echo escape_html($option); ?></option><?php endforeach; ?></select></div>
                <button class="button button-primary directory-filter-button" type="submit">Apply filters</button>
                <?php if (!empty($queryParameters)) : ?><a class="directory-reset" href="alumni.php">Clear all</a><?php endif; ?>
            </form>

            <?php if (empty($members)) : ?>
                <section class="directory-empty"><span class="directory-empty-icon">◎</span><h2>No members found</h2><p>Try adjusting your search or filters to discover more of the community.</p><a class="button button-secondary" href="alumni.php">Reset search</a></section>
            <?php else : ?>
                <section class="member-card-grid" aria-label="Directory members">
                    <?php foreach ($members as $member) : ?>
                        <?php $memberImage = !empty($member['profile_image']) ? basename($member['profile_image']) : ''; ?>
                        <article class="member-card">
                            <div class="member-card-top">
                                <?php if ($memberImage !== '') : ?><img class="member-card-avatar" src="uploads/profiles/<?php echo escape_html($memberImage); ?>" alt="<?php echo escape_html($member['name']); ?> profile image"><?php else : ?><span class="member-card-avatar member-card-avatar-fallback"><?php echo escape_html(strtoupper(substr($member['name'], 0, 1))); ?></span><?php endif; ?>
                                <span class="member-role-badge"><?php echo escape_html(ucfirst($member['role'])); ?></span>
                            </div>
                            <h2><?php echo escape_html($member['name']); ?></h2>
                            <?php if (!empty($member['designation']) || !empty($member['company'])) : ?><p class="member-card-position"><?php echo escape_html($member['designation'] ?: 'Professional'); ?><?php if (!empty($member['company'])) : ?> · <?php echo escape_html($member['company']); ?><?php endif; ?></p><?php endif; ?>
                            <div class="member-card-meta"><?php if (!empty($member['department'])) : ?><span>▦ <?php echo escape_html($member['department']); ?></span><?php endif; ?><?php if (!empty($member['graduation_year'])) : ?><span>◷ Class of <?php echo escape_html($member['graduation_year']); ?></span><?php endif; ?><?php if (empty($member['department']) && empty($member['graduation_year'])) : ?><span>Profile details coming soon</span><?php endif; ?></div>
                            <a class="button button-secondary member-card-link" href="view-profile.php?id=<?php echo (int) $member['id']; ?>">View profile <span aria-hidden="true">→</span></a>
                        </article>
                    <?php endforeach; ?>
                </section>
                <?php if ($totalPages > 1) : ?><nav class="pagination" aria-label="Directory pagination"><?php if ($page > 1) : ?><a class="pagination-link" href="alumni.php?<?php echo http_build_query(array_merge($queryParameters, array('page' => $page - 1))); ?>">← Previous</a><?php else : ?><span class="pagination-link is-disabled">← Previous</span><?php endif; ?><span class="pagination-status">Page <?php echo $page; ?> of <?php echo $totalPages; ?></span><?php if ($page < $totalPages) : ?><a class="pagination-link" href="alumni.php?<?php echo http_build_query(array_merge($queryParameters, array('page' => $page + 1))); ?>">Next →</a><?php else : ?><span class="pagination-link is-disabled">Next →</span><?php endif; ?></nav><?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>