<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<main>
    <section class="hero-section">
        <div class="container hero-grid">
            <div class="hero-content">
                <p class="eyebrow">AlumniConnect</p>
                <h1>Build meaningful connections beyond the classroom.</h1>
                <p class="hero-text">
                    A focused alumni network that helps students and graduates discover
                    people, opportunities and events that move their careers forward.
                </p>
                <div class="hero-actions">
                    <a class="button button-primary" href="register.php">Create your account</a>
                    <a class="button button-secondary" href="login.php">Sign in</a>
                </div>
                <div class="hero-note">
                    <span class="status-dot" aria-hidden="true"></span>
                    Connect with your college community
                </div>
            </div>

            <div class="hero-visual" aria-label="Illustration of connected alumni profiles">
                <div class="network-card network-card-main">
                    <div class="network-card-heading">
                        <span class="icon-badge icon-badge-blue">AC</span>
                        <span>
                            <strong>Your network</strong>
                            <small>Growing with every connection</small>
                        </span>
                    </div>
                    <div class="network-lines" aria-hidden="true">
                        <span class="line line-one"></span>
                        <span class="line line-two"></span>
                        <span class="line line-three"></span>
                        <span class="node node-center">AC</span>
                        <span class="node node-one">S</span>
                        <span class="node node-two">A</span>
                        <span class="node node-three">R</span>
                    </div>
                    <div class="network-card-footer">
                        <span class="mini-avatar avatar-blue">S</span>
                        <span class="mini-avatar avatar-gold">A</span>
                        <span class="mini-avatar avatar-green">R</span>
                        <span class="network-label">People making progress together</span>
                    </div>
                </div>
                <div class="floating-card floating-card-event">
                    <span class="floating-icon">◆</span>
                    <span><strong>New event</strong><small>Explore what is happening</small></span>
                </div>
                <div class="floating-card floating-card-career">
                    <span class="floating-icon floating-icon-green">↗</span>
                    <span><strong>Career paths</strong><small>Learn from your network</small></span>
                </div>
            </div>
        </div>
    </section>

    <section class="section section-light" id="features">
        <div class="container">
            <div class="section-heading">
                <p class="eyebrow">Everything in one place</p>
                <h2>Make your alumni network work for you.</h2>
                <p>Stay connected to a community built around shared experiences and future opportunities.</p>
            </div>
            <div class="feature-grid">
                <article class="feature-card">
                    <div class="feature-icon feature-icon-blue" aria-hidden="true">↗</div>
                    <h3>Alumni networking</h3>
                    <p>Find and connect with students and alumni who share your interests, path or goals.</p>
                    <a href="register.php" class="text-link">Join the network <span aria-hidden="true">→</span></a>
                </article>
                <article class="feature-card">
                    <div class="feature-icon feature-icon-purple" aria-hidden="true">▣</div>
                    <h3>Career opportunities</h3>
                    <p>Discover relevant jobs and learn from the professional journeys of your community.</p>
                    <a href="register.php" class="text-link">Explore possibilities <span aria-hidden="true">→</span></a>
                </article>
                <article class="feature-card">
                    <div class="feature-icon feature-icon-gold" aria-hidden="true">◆</div>
                    <h3>College events</h3>
                    <p>Keep up with events, meetups and conversations that bring your community together.</p>
                    <a href="register.php" class="text-link">See what is next <span aria-hidden="true">→</span></a>
                </article>
                <article class="feature-card">
                    <div class="feature-icon feature-icon-green" aria-hidden="true">◎</div>
                    <h3>Professional profiles</h3>
                    <p>Share your experience, skills and interests so the right people can find you.</p>
                    <a href="register.php" class="text-link">Build your profile <span aria-hidden="true">→</span></a>
                </article>
            </div>
        </div>
    </section>

    <section class="section how-section" id="how-it-works">
        <div class="container how-grid">
            <div class="section-heading section-heading-left">
                <p class="eyebrow">How it works</p>
                <h2>Start with one simple step.</h2>
                <p>AlumniConnect makes it easy to turn a shared college experience into a lasting professional connection.</p>
                <a class="button button-primary" href="register.php">Get started today</a>
            </div>
            <div class="steps-list">
                <div class="step-item">
                    <span class="step-number">01</span>
                    <div><h3>Create your profile</h3><p>Introduce yourself with the experience, interests and skills you want to share.</p></div>
                </div>
                <div class="step-item">
                    <span class="step-number">02</span>
                    <div><h3>Discover your community</h3><p>Browse people, events and opportunities that match where you want to go.</p></div>
                </div>
                <div class="step-item">
                    <span class="step-number">03</span>
                    <div><h3>Connect and grow</h3><p>Start conversations, exchange ideas and support the next chapter of your journey.</p></div>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container cta-content">
            <div>
                <p class="eyebrow eyebrow-light">Your next connection starts here</p>
                <h2>Keep your college community close.</h2>
                <p>Join AlumniConnect and take the next step with people who understand your journey.</p>
            </div>
            <a class="button button-light" href="register.php">Join AlumniConnect <span aria-hidden="true">→</span></a>
        </div>
    </section>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>