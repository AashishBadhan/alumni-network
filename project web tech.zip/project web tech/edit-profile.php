<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$profile = false;
try {
    $statement = $pdo->prepare(
        "SELECT u.name, u.role, u.status, p.department, p.graduation_year, p.phone,
                p.city, p.bio, p.education, p.skills, p.company, p.designation,
                p.linkedin, p.github, p.profile_image
         FROM users u LEFT JOIN profiles p ON p.user_id = u.id
         WHERE u.id = :user_id LIMIT 1"
    );
    $statement->execute(array(':user_id' => $currentUser['id']));
    $profile = $statement->fetch();
} catch (PDOException $exception) {
    error_log('AlumniConnect edit profile load failed. PDO error code: ' . $exception->getCode());
}
if ($profile === false || $profile['status'] !== 'active') {
    $_SESSION = array();
    session_destroy();
    header('Location: login.php');
    exit;
}

$errors = isset($_SESSION['profile_errors']) ? $_SESSION['profile_errors'] : array();
$oldInput = isset($_SESSION['profile_old_input']) ? $_SESSION['profile_old_input'] : array();
unset($_SESSION['profile_errors'], $_SESSION['profile_old_input']);
$formValues = array_merge($profile, $oldInput);

$pageTitle = 'Edit Profile | AlumniConnect';
$pageDescription = 'Update your AlumniConnect profile information.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button>
            <div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Edit profile</strong></div>
            <a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($profile['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($profile['name']); ?></strong><small><?php echo escape_html(ucfirst($profile['role'])); ?></small></span></a>
        </header>
        <main class="dashboard-main profile-page-main">
            <a class="back-link" href="profile.php">← Back to profile</a>
            <section class="directory-heading"><div><p class="eyebrow">Keep your profile current</p><h1>Edit your profile</h1><p>Share the details that help your community get to know you.</p></div></section>
            <?php if (!empty($errors)) : ?><div class="form-alert form-alert-error" role="alert"><strong>Please review the following:</strong><ul><?php foreach ($errors as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
            <form class="profile-edit-form" action="actions/profile.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>">
                <section class="dashboard-panel"><p class="panel-eyebrow">Basics</p><h2>Personal information</h2>
                    <div class="form-field"><label for="name">Full name</label><input id="name" name="name" type="text" maxlength="100" required value="<?php echo escape_html($formValues['name']); ?>"></div>
                    <div class="form-row"><div class="form-field"><label for="department">Department</label><input id="department" name="department" type="text" maxlength="100" value="<?php echo escape_html($formValues['department']); ?>"></div><div class="form-field"><label for="graduation_year">Graduation year</label><input id="graduation_year" name="graduation_year" type="number" min="1901" max="<?php echo date('Y') + 10; ?>" value="<?php echo escape_html($formValues['graduation_year']); ?>"></div></div>
                    <div class="form-row"><div class="form-field"><label for="phone">Phone</label><input id="phone" name="phone" type="tel" maxlength="20" value="<?php echo escape_html($formValues['phone']); ?>"></div><div class="form-field"><label for="city">City</label><input id="city" name="city" type="text" maxlength="100" value="<?php echo escape_html($formValues['city']); ?>"></div></div>
                    <div class="form-field"><label for="bio">Bio</label><textarea id="bio" name="bio" maxlength="2000" rows="5"><?php echo escape_html($formValues['bio']); ?></textarea></div>
                </section>
                <section class="dashboard-panel"><p class="panel-eyebrow">Experience</p><h2>Professional details</h2>
                    <div class="form-row"><div class="form-field"><label for="company">Company</label><input id="company" name="company" type="text" maxlength="150" value="<?php echo escape_html($formValues['company']); ?>"></div><div class="form-field"><label for="designation">Designation</label><input id="designation" name="designation" type="text" maxlength="150" value="<?php echo escape_html($formValues['designation']); ?>"></div></div>
                    <div class="form-field"><label for="education">Education</label><textarea id="education" name="education" maxlength="2000" rows="4"><?php echo escape_html($formValues['education']); ?></textarea></div>
                    <div class="form-field"><label for="skills">Skills</label><textarea id="skills" name="skills" maxlength="2000" rows="4"><?php echo escape_html($formValues['skills']); ?></textarea></div>
                </section>
                <section class="dashboard-panel"><p class="panel-eyebrow">Online presence</p><h2>Links and profile photo</h2>
                    <div class="form-field"><label for="linkedin">LinkedIn URL</label><input id="linkedin" name="linkedin" type="url" maxlength="255" placeholder="https://www.linkedin.com/in/your-name" value="<?php echo escape_html($formValues['linkedin']); ?>"></div>
                    <div class="form-field"><label for="github">GitHub URL</label><input id="github" name="github" type="url" maxlength="255" placeholder="https://github.com/your-name" value="<?php echo escape_html($formValues['github']); ?>"></div>
                    <div class="form-field"><label for="profile_image">Profile image <small>(JPEG, PNG or WebP, max 2 MB)</small></label><input id="profile_image" name="profile_image" type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"></div>
                    <?php if (!empty($profile['profile_image'])) : ?><p class="current-image-note">A profile image is already saved. It will remain unchanged if a replacement upload fails.</p><?php endif; ?>
                </section>
                <div class="profile-form-actions"><a class="button button-secondary" href="profile.php">Cancel</a><button class="button button-primary" type="submit">Save changes <span aria-hidden="true">→</span></button></div>
            </form>
        </main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>