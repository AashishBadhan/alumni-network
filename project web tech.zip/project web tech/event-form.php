<?php
$formEvent = isset($event) && is_array($event) ? $event : array();
$oldEventInput = isset($_SESSION['event_old_input']) ? $_SESSION['event_old_input'] : array();
unset($_SESSION['event_old_input']);
$formEvent = array_merge($formEvent, $oldEventInput);
$formAction = isset($formEvent['id']) ? 'update' : 'create';
$eventDateValue = !empty($formEvent['event_date']) ? date('Y-m-d\TH:i', strtotime($formEvent['event_date'])) : '';
?>
<form class="event-form profile-edit-form" action="actions/event.php" method="post">
    <input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>">
    <input type="hidden" name="action" value="<?php echo $formAction; ?>">
    <?php if ($formAction === 'update') : ?><input type="hidden" name="event_id" value="<?php echo (int) $formEvent['id']; ?>"><?php endif; ?>
    <section class="dashboard-panel"><p class="panel-eyebrow">Event details</p><h2>Set the scene</h2>
        <div class="form-field"><label for="title">Event title</label><input id="title" name="title" type="text" maxlength="200" required value="<?php echo escape_html(isset($formEvent['title']) ? $formEvent['title'] : ''); ?>"></div>
        <div class="form-field"><label for="description">Description</label><textarea id="description" name="description" maxlength="5000" rows="7" required><?php echo escape_html(isset($formEvent['description']) ? $formEvent['description'] : ''); ?></textarea></div>
        <div class="form-row"><div class="form-field"><label for="event_date">Date and time</label><input id="event_date" name="event_date" type="datetime-local" required value="<?php echo escape_html($eventDateValue); ?>"></div><div class="form-field"><label for="location">Location</label><input id="location" name="location" type="text" maxlength="200" required value="<?php echo escape_html(isset($formEvent['location']) ? $formEvent['location'] : ''); ?>"></div></div>
        <div class="form-field"><label for="category">Category</label><input id="category" name="category" type="text" maxlength="100" required placeholder="e.g. Networking, Workshop" value="<?php echo escape_html(isset($formEvent['category']) ? $formEvent['category'] : ''); ?>"></div>
    </section>
    <div class="profile-form-actions"><a class="button button-secondary" href="events.php">Cancel</a><button class="button button-primary" type="submit"><?php echo $formAction === 'update' ? 'Save changes' : 'Create event'; ?> <span aria-hidden="true">→</span></button></div>
</form>
