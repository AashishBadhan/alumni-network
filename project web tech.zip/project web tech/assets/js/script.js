document.addEventListener('DOMContentLoaded', function () {
    var menuToggle = document.querySelector('.menu-toggle');
    var navigation = document.querySelector('.primary-navigation');

    if (menuToggle && navigation) {
        menuToggle.addEventListener('click', function () {
            var isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', String(!isOpen));
            navigation.classList.toggle('is-open', !isOpen);
            document.body.classList.toggle('menu-is-open', !isOpen);
        });

        navigation.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                menuToggle.setAttribute('aria-expanded', 'false');
                navigation.classList.remove('is-open');
                document.body.classList.remove('menu-is-open');
            });
        });
    }

    var dashboardToggle = document.querySelector('.dashboard-menu-toggle');
    var dashboardSidebar = document.querySelector('.dashboard-sidebar');

    if (dashboardToggle && dashboardSidebar) {
        dashboardToggle.addEventListener('click', function () {
            var isOpen = dashboardToggle.getAttribute('aria-expanded') === 'true';
            dashboardToggle.setAttribute('aria-expanded', String(!isOpen));
            dashboardSidebar.classList.toggle('is-open', !isOpen);
        });

        dashboardSidebar.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                dashboardToggle.setAttribute('aria-expanded', 'false');
                dashboardSidebar.classList.remove('is-open');
            });
        });
    }
});