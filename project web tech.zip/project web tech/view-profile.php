<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$profileId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$profile = false;
$connectionState = '';
$connectionId = 0;

if ($profileId !== false && $profileId !== null && $profileId > 0) {
    try {
        $activeAccountStatement = $pdo->prepare('SELECT status FROM users WHERE id = :user_id LIMIT 1');
        $activeAccountStatement->execute(array(':user_id' => $currentUser['id']));
        $activeAccount = $activeAccountStatement->fetch();
        if ($activeAccount === false || $activeAccount['status'] !== 'active') {
            $_SESSION = array();
            session_destroy();
            header('Location: login.php');
            exit;
        }

        $profileStatement = $pdo->prepare(
            "SELECT u.id, u.name, u.role, p.department, p.graduation_year, p.phone,
                    p.city, p.bio, p.company, p.designation, p.skills, p.education,
                    p.linkedin, p.github, p.profile_image
             FROM users u
             INNER JOIN profiles p ON p.user_id = u.id
             WHERE u.id = :profile_id
               AND u.status = 'active'
               AND u.role IN ('student', 'alumni')
             LIMIT 1"
        );
        $profileStatement->execute(array(':profile_id' => $profileId));
        $profile = $profileStatement->fetch();
        if ($profile !== false && (int) $profile['id'] !== (int) $currentUser['id']) {
            $connectionStatement = $pdo->prepare(
                'SELECT id, sender_id, receiver_id, status
                 FROM connections
                 WHERE pair_low_id = :pair_low AND pair_high_id = :pair_high
                 LIMIT 1'
            );
            $connectionStatement->execute(array(
                ':pair_low' => min((int) $currentUser['id'], (int) $profileId),
                ':pair_high' => max((int) $currentUser['id'], (int) $profileId),
            ));
            $connection = $connectionStatement->fetch();
            if ($connection !== false) {
                $connectionId = (int) $connection['id'];
                $connectionState = $connection['status'];
            }
        }
    } catch (PDOException $exception) {
        error_log('AlumniConnect profile query failed. PDO error code: ' . $exception->getCode());
    }
}

$pageTitle = $profile !== false ? $profile['name'] . ' | AlumniConnect' : 'Profile not found | AlumniConnect';
$pageDescription = 'View a public AlumniConnect member profile.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button>
            <div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Member profile</strong></div>
            <a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a>
        </header>
        <main class="dashboard-main profile-page-main">
            <?php if ($profile === false) : ?>
                <section class="directory-empty profile-not-found"><span class="directory-empty-icon">?</span><h1>Profile not found</h1><p>This member profile is unavailable or no longer public.</p><a class="button button-primary" href="alumni.php">Back to directory</a></section>
            <?php else : ?>
                <?php $profileImage = !empty($profile['profile_image']) ? basename($profile['profile_image']) : ''; ?>
                <a class="back-link" href="alumni.php">← Back to directory</a>
                <section class="profile-hero-card">
                    <div class="profile-hero-identity"><?php if ($profileImage !== '') : ?><img class="profile-large-avatar" src="uploads/profiles/<?php echo escape_html($profileImage); ?>" alt="<?php echo escape_html($profile['name']); ?> profile image"><?php else : ?><span class="profile-large-avatar profile-large-avatar-fallback"><?php echo escape_html(strtoupper(substr($profile['name'], 0, 1))); ?></span><?php endif; ?><div><span class="member-role-badge"><?php echo escape_html(ucfirst($profile['role'])); ?></span><h1><?php echo escape_html($profile['name']); ?></h1><?php if (!empty($profile['designation']) || !empty($profile['company'])) : ?><p><?php echo escape_html($profile['designation'] ?: 'Professional'); ?><?php if (!empty($profile['company'])) : ?> · <?php echo escape_html($profile['company']); ?><?php endif; ?></p><?php endif; ?></div></div>
                    <?php if (!empty($profile['city']) || !empty($profile['department']) || !empty($profile['graduation_year'])) : ?><div class="profile-hero-meta"><?php if (!empty($profile['city'])) : ?><span>⌖ <?php echo escape_html($profile['city']); ?></span><?php endif; ?><?php if (!empty($profile['department'])) : ?><span>▦ <?php echo escape_html($profile['department']); ?></span><?php endif; ?><?php if (!empty($profile['graduation_year'])) : ?><span>◷ Class of <?php echo escape_html($profile['graduation_year']); ?></span><?php endif; ?></div><?php endif; ?>
                </section>
                <section class="profile-connection-action">
                    <?php if ($connectionState === '' || $connectionState === 'rejected') : ?>
                        <form action="actions/connection.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="send"><input type="hidden" name="target_id" value="<?php echo (int) $profile['id']; ?>"><button class="button button-primary" type="submit">Send connection request <span aria-hidden="true">→</span></button></form>
                    <?php elseif ($connectionState === 'pending') : ?>
                        <p class="connection-status">A connection request is already pending.</p>
                    <?php elseif ($connectionState === 'accepted') : ?>
                        <p class="connection-status connection-status-success">You are connected with this member.</p>
                    <?php endif; ?>
                </section>
                <div class="profile-details-grid">
                    <section class="dashboard-panel profile-detail-panel"><p class="panel-eyebrow">About</p><h2>About <?php echo escape_html(explode(' ', trim($profile['name']))[0]); ?></h2><?php if (!empty($profile['bio'])) : ?><p class="profile-body-text"><?php echo nl2br(escape_html($profile['bio'])); ?></p><?php else : ?><p class="empty-state">This member has not added a bio yet.</p><?php endif; ?><?php if (!empty($profile['education'])) : ?><div class="profile-detail-block"><h3>Education</h3><p><?php echo nl2br(escape_html($profile['education'])); ?></p></div><?php endif; ?><?php if (!empty($profile['skills'])) : ?><div class="profile-detail-block"><h3>Skills</h3><p><?php echo nl2br(escape_html($profile['skills'])); ?></p></div><?php endif; ?></section>
                    <aside class="dashboard-panel profile-detail-panel"><p class="panel-eyebrow">Professional details</p><h2>Experience</h2><?php if (!empty($profile['company']) || !empty($profile['designation'])) : ?><div class="experience-item"><span class="stat-icon stat-icon-blue">↗</span><div><strong><?php echo escape_html($profile['designation'] ?: 'Professional'); ?></strong><p><?php echo escape_html($profile['company'] ?: 'Company not specified'); ?></p></div></div><?php else : ?><p class="empty-state">No professional details added yet.</p><?php endif; ?><?php if (!empty($profile['linkedin']) || !empty($profile['github'])) : ?><div class="profile-links"><?php if (!empty($profile['linkedin'])) : ?><a href="<?php echo escape_html($profile['linkedin']); ?>" target="_blank" rel="noopener noreferrer">LinkedIn <span>↗</span></a><?php endif; ?><?php if (!empty($profile['github'])) : ?><a href="<?php echo escape_html($profile['github']); ?>" target="_blank" rel="noopener noreferrer">GitHub <span>↗</span></a><?php endif; ?></div><?php endif; ?></aside>
                </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>