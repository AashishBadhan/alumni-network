<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';
$currentUser = get_current_user_info();
$pageTitle = 'Create Event | AlumniConnect';
$pageDescription = 'Create a community event on AlumniConnect.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar"><button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button><div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Create event</strong></div><a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a></header>
        <main class="dashboard-main event-form-main"><a class="back-link" href="events.php">← Back to events</a><section class="directory-heading"><div><p class="eyebrow">Bring the community together</p><h1>Create an event</h1><p>Share a gathering, workshop or conversation with students and alumni.</p></div></section><?php if (!empty($_SESSION['event_errors'])) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($_SESSION['event_errors'] as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php unset($_SESSION['event_errors']); endif; ?><?php require __DIR__ . '/event-form.php'; ?></main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>