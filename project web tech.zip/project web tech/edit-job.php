<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';
$currentUser = get_current_user_info();
$jobId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$job = false;
if ($jobId !== false && $jobId > 0) {
    $statement = $pdo->prepare('SELECT j.*, u.status AS creator_status FROM jobs j INNER JOIN users u ON u.id = j.user_id WHERE j.id = :job_id LIMIT 1');
    $statement->execute(array(':job_id' => $jobId));
    $job = $statement->fetch();
}
if ($job === false || $job['creator_status'] !== 'active' || ((int) $job['user_id'] !== (int) $currentUser['id'] && $currentUser['role'] !== 'admin')) {
    http_response_code(403);
    exit('You do not have permission to edit this job.');
}
$pageTitle = 'Edit Job | AlumniConnect';
$pageDescription = 'Edit your AlumniConnect job post.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar"><button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button><div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Edit job</strong></div><a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a></header>
        <main class="dashboard-main job-form-main"><a class="back-link" href="jobs.php?view=<?php echo (int) $job['id']; ?>">← Back to job</a><section class="directory-heading"><div><p class="eyebrow">Keep your opportunity current</p><h1>Edit job post</h1><p>Update the details applicants need to know.</p></div></section><?php if (!empty($_SESSION['job_errors'])) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($_SESSION['job_errors'] as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php unset($_SESSION['job_errors']); endif; ?><?php require __DIR__ . '/job-form.php'; ?></main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>