<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$currentUser = get_current_user_info();
$notifications = array();
$notificationError = '';

try {
    $accountStatement = $pdo->prepare('SELECT status FROM users WHERE id = :user_id LIMIT 1');
    $accountStatement->execute(array(':user_id' => $currentUser['id']));
    $account = $accountStatement->fetch();
    if ($account === false || $account['status'] !== 'active') {
        $_SESSION = array();
        session_destroy();
        header('Location: login.php');
        exit;
    }

    $notificationStatement = $pdo->prepare(
        'SELECT id, message, type, related_id, is_read, created_at
         FROM notifications
         WHERE user_id = :user_id
         ORDER BY created_at DESC, id DESC'
    );
    $notificationStatement->execute(array(':user_id' => $currentUser['id']));
    $notifications = $notificationStatement->fetchAll();
} catch (PDOException $exception) {
    error_log('AlumniConnect notifications query failed. PDO error code: ' . $exception->getCode());
    $notificationError = 'Notifications are temporarily unavailable. Please try again later.';
}

$unreadCount = 0;
foreach ($notifications as $notification) {
    if ((int) $notification['is_read'] === 0) {
        $unreadCount++;
    }
}

$pageTitle = 'Notifications | AlumniConnect';
$pageDescription = 'View and manage your AlumniConnect notifications.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false">
                <span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span>
            </button>
            <div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>Notifications</strong></div>
            <a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($currentUser['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($currentUser['name']); ?></strong><small><?php echo escape_html(ucfirst($currentUser['role'])); ?></small></span></a>
        </header>

        <main class="dashboard-main notifications-main">
            <section class="directory-heading">
                <div><p class="eyebrow">Stay up to date</p><h1>Your notifications</h1><p>Keep track of connection activity, events and other updates.</p></div>
                <?php if ($unreadCount > 0) : ?><form action="actions/notification.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="mark_all_read"><button class="button button-secondary" type="submit">Mark all as read</button></form><?php endif; ?>
            </section>

            <?php if ($notificationError !== '') : ?><div class="form-alert form-alert-error" role="alert"><?php echo escape_html($notificationError); ?></div><?php endif; ?>
            <?php if (!empty($_SESSION['notification_success'])) : ?><div class="form-alert form-alert-success" role="status"><?php echo escape_html($_SESSION['notification_success']); ?></div><?php unset($_SESSION['notification_success']); endif; ?>
            <?php if (!empty($_SESSION['notification_errors'])) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($_SESSION['notification_errors'] as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php unset($_SESSION['notification_errors']); endif; ?>

            <?php if (empty($notifications)) : ?>
                <section class="directory-empty"><span class="directory-empty-icon">◌</span><h2>No notifications yet</h2><p>Updates about your connections, events and opportunities will appear here.</p><a class="button button-secondary" href="dashboard.php">Back to dashboard</a></section>
            <?php else : ?>
                <section class="notification-list" aria-label="Your notifications">
                    <?php foreach ($notifications as $notification) : ?>
                        <article class="notification-card <?php echo (int) $notification['is_read'] === 0 ? 'is-unread' : ''; ?>">
                            <span class="notification-type-icon" aria-hidden="true"><?php echo escape_html(get_notification_icon($notification['type'])); ?></span>
                            <div class="notification-card-content"><p><?php echo escape_html($notification['message']); ?></p><small><?php echo escape_html(ucwords(str_replace('_', ' ', $notification['type'] ?: 'update'))); ?> · <?php echo escape_html(date('M j, Y \a\t g:i A', strtotime($notification['created_at']))); ?></small></div>
                            <div class="notification-card-actions">
                                <?php if ((int) $notification['is_read'] === 0) : ?><form action="actions/notification.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="mark_read"><input type="hidden" name="notification_id" value="<?php echo (int) $notification['id']; ?>"><button class="text-button" type="submit">Mark read</button></form><?php endif; ?>
                                <form action="actions/notification.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="notification_id" value="<?php echo (int) $notification['id']; ?>"><button class="text-button text-button-danger" type="submit">Delete</button></form>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </section>
            <?php endif; ?>
        </main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>