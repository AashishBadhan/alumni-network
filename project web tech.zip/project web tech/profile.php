<?php
require_once __DIR__ . '/includes/auth.php';
require_authentication();
require_once __DIR__ . '/includes/db.php';

$currentUser = get_current_user_info();
$profile = false;

try {
    $statement = $pdo->prepare(
        "SELECT u.name, u.role, u.status, p.department, p.graduation_year, p.phone,
                p.city, p.bio, p.education, p.skills, p.company, p.designation,
                p.linkedin, p.github, p.profile_image
         FROM users u
         LEFT JOIN profiles p ON p.user_id = u.id
         WHERE u.id = :user_id
         LIMIT 1"
    );
    $statement->execute(array(':user_id' => $currentUser['id']));
    $profile = $statement->fetch();
} catch (PDOException $exception) {
    error_log('AlumniConnect profile load failed. PDO error code: ' . $exception->getCode());
}

if ($profile === false || $profile['status'] !== 'active') {
    $_SESSION = array();
    session_destroy();
    header('Location: login.php');
    exit;
}

$profileFields = array(
    'department', 'graduation_year', 'phone', 'city', 'bio', 'education',
    'skills', 'company', 'designation', 'linkedin', 'github',
);
$completedFields = 0;
foreach ($profileFields as $field) {
    if (!empty($profile[$field])) {
        $completedFields++;
    }
}
$completion = (int) round(($completedFields / count($profileFields)) * 100);
$message = isset($_SESSION['profile_success']) ? $_SESSION['profile_success'] : '';
$errors = isset($_SESSION['profile_errors']) ? $_SESSION['profile_errors'] : array();
unset($_SESSION['profile_success'], $_SESSION['profile_errors']);

$pageTitle = 'My Profile | AlumniConnect';
$pageDescription = 'View your AlumniConnect profile.';
$bodyClass = 'dashboard-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard-layout">
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <div class="dashboard-content">
        <header class="dashboard-topbar">
            <button class="dashboard-menu-toggle" type="button" aria-controls="dashboard-sidebar" aria-expanded="false"><span class="sr-only">Toggle dashboard menu</span><span class="menu-bar"></span><span class="menu-bar"></span><span class="menu-bar"></span></button>
            <div class="dashboard-topbar-copy"><span class="dashboard-kicker">AlumniConnect workspace</span><strong>My profile</strong></div>
            <a class="dashboard-account" href="profile.php"><span class="dashboard-avatar"><?php echo escape_html(strtoupper(substr($profile['name'], 0, 1))); ?></span><span class="dashboard-account-details"><strong><?php echo escape_html($profile['name']); ?></strong><small><?php echo escape_html(ucfirst($profile['role'])); ?></small></span></a>
        </header>

        <main class="dashboard-main profile-page-main">
            <?php if ($message !== '') : ?><div class="form-alert form-alert-success" role="status"><?php echo escape_html($message); ?></div><?php endif; ?>
            <?php if (!empty($errors)) : ?><div class="form-alert form-alert-error" role="alert"><ul><?php foreach ($errors as $error) : ?><li><?php echo escape_html($error); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
            <section class="profile-hero-card">
                <div class="profile-hero-identity">
                    <?php if (!empty($profile['profile_image'])) : ?><img class="profile-large-avatar" src="uploads/profiles/<?php echo escape_html(basename($profile['profile_image'])); ?>" alt="<?php echo escape_html($profile['name']); ?> profile image"><?php else : ?><span class="profile-large-avatar profile-large-avatar-fallback"><?php echo escape_html(strtoupper(substr($profile['name'], 0, 1))); ?></span><?php endif; ?>
                    <div><span class="member-role-badge"><?php echo escape_html(ucfirst($profile['role'])); ?></span><h1><?php echo escape_html($profile['name']); ?></h1><?php if (!empty($profile['designation']) || !empty($profile['company'])) : ?><p><?php echo escape_html($profile['designation'] ?: 'Professional'); ?><?php if (!empty($profile['company'])) : ?> · <?php echo escape_html($profile['company']); ?><?php endif; ?></p><?php endif; ?></div>
                </div>
                <a class="button button-light" href="edit-profile.php">Edit profile <span aria-hidden="true">→</span></a>
            </section>

            <div class="profile-completion-panel">
                <div><p class="panel-eyebrow">Profile strength</p><strong><?php echo $completion; ?>% complete</strong><p><?php echo $completion < 100 ? 'Add more details to help your community discover you.' : 'Your profile is ready to represent your journey.'; ?></p></div>
                <div class="progress-track"><span style="width: <?php echo $completion; ?>%;"></span></div>
            </div>

            <div class="profile-details-grid">
                <section class="dashboard-panel profile-detail-panel"><p class="panel-eyebrow">Personal information</p><h2>About me</h2><dl class="profile-info-list">
                    <?php foreach (array('department' => 'Department', 'graduation_year' => 'Graduation year', 'phone' => 'Phone', 'city' => 'City') as $field => $label) : ?><?php if (!empty($profile[$field])) : ?><div><dt><?php echo $label; ?></dt><dd><?php echo escape_html($profile[$field]); ?></dd></div><?php endif; ?><?php endforeach; ?>
                </dl><?php if (!empty($profile['bio'])) : ?><div class="profile-detail-block"><h3>Bio</h3><p><?php echo nl2br(escape_html($profile['bio'])); ?></p></div><?php endif; ?></section>
                <section class="dashboard-panel profile-detail-panel"><p class="panel-eyebrow">Professional journey</p><h2>Experience and education</h2><?php if (!empty($profile['company']) || !empty($profile['designation'])) : ?><div class="experience-item"><span class="stat-icon stat-icon-blue">↗</span><div><strong><?php echo escape_html($profile['designation'] ?: 'Professional'); ?></strong><p><?php echo escape_html($profile['company'] ?: 'Company not specified'); ?></p></div></div><?php endif; ?><?php if (!empty($profile['education'])) : ?><div class="profile-detail-block"><h3>Education</h3><p><?php echo nl2br(escape_html($profile['education'])); ?></p></div><?php endif; ?><?php if (!empty($profile['skills'])) : ?><div class="profile-detail-block"><h3>Skills</h3><p><?php echo nl2br(escape_html($profile['skills'])); ?></p></div><?php endif; ?><?php if (empty($profile['company']) && empty($profile['designation']) && empty($profile['education']) && empty($profile['skills'])) : ?><p class="empty-state">Add your experience, education and skills to complete your profile.</p><?php endif; ?></section>
            </div>
            <?php if (!empty($profile['linkedin']) || !empty($profile['github'])) : ?><section class="dashboard-panel profile-social-panel"><p class="panel-eyebrow">Online presence</p><h2>Professional links</h2><div class="profile-links"><?php if (!empty($profile['linkedin'])) : ?><a href="<?php echo escape_html($profile['linkedin']); ?>" target="_blank" rel="noopener noreferrer">LinkedIn <span>↗</span></a><?php endif; ?><?php if (!empty($profile['github'])) : ?><a href="<?php echo escape_html($profile['github']); ?>" target="_blank" rel="noopener noreferrer">GitHub <span>↗</span></a><?php endif; ?></div></section><?php endif; ?>
        </main>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>