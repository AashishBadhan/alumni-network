<?php
require_once __DIR__ . '/includes/auth.php';
start_secure_session();

$errors = isset($_SESSION['registration_errors']) ? $_SESSION['registration_errors'] : array();
$oldInput = isset($_SESSION['registration_old_input']) ? $_SESSION['registration_old_input'] : array();
unset($_SESSION['registration_errors'], $_SESSION['registration_old_input']);

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<main class="auth-page">
    <div class="container auth-container">
        <section class="auth-intro">
            <p class="eyebrow">Join the community</p>
            <h1>Make your next connection meaningful.</h1>
            <p>Build your professional profile and become part of a community that grows together.</p>
            <div class="auth-highlights">
                <span>Connect with students and alumni</span>
                <span>Discover opportunities and events</span>
                <span>Share your journey with confidence</span>
            </div>
        </section>

        <section class="auth-card" aria-labelledby="registration-title">
            <p class="eyebrow">Create an account</p>
            <h2 id="registration-title">Join AlumniConnect</h2>
            <p class="auth-card-subtitle">Use your details to get started.</p>

            <?php if (!empty($errors)) : ?>
                <div class="form-alert form-alert-error" role="alert">
                    <strong>Please review the following:</strong>
                    <ul>
                        <?php foreach ($errors as $error) : ?>
                            <li><?php echo escape_html($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="actions/register.php" method="post" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>">
                <div class="form-field">
                    <label for="name">Full name</label>
                    <input type="text" id="name" name="name" maxlength="100" autocomplete="name" required value="<?php echo escape_html(isset($oldInput['name']) ? $oldInput['name'] : ''); ?>">
                </div>
                <div class="form-field">
                    <label for="email">Email address</label>
                    <input type="email" id="email" name="email" maxlength="150" autocomplete="email" required value="<?php echo escape_html(isset($oldInput['email']) ? $oldInput['email'] : ''); ?>">
                </div>
                <div class="form-row">
                    <div class="form-field">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" minlength="8" autocomplete="new-password" required>
                    </div>
                    <div class="form-field">
                        <label for="confirm_password">Confirm password</label>
                        <input type="password" id="confirm_password" name="confirm_password" minlength="8" autocomplete="new-password" required>
                    </div>
                </div>
                <fieldset class="form-field role-field">
                    <legend>I am a</legend>
                    <div class="role-options">
                        <label class="role-option">
                            <input type="radio" name="role" value="student" <?php echo (!isset($oldInput['role']) || $oldInput['role'] === 'student') ? 'checked' : ''; ?>>
                            <span><strong>Student</strong><small>Build your network</small></span>
                        </label>
                        <label class="role-option">
                            <input type="radio" name="role" value="alumni" <?php echo (isset($oldInput['role']) && $oldInput['role'] === 'alumni') ? 'checked' : ''; ?>>
                            <span><strong>Alumni</strong><small>Share your experience</small></span>
                        </label>
                    </div>
                </fieldset>
                <button class="button button-primary form-submit" type="submit">Create account <span aria-hidden="true">→</span></button>
            </form>
            <p class="auth-switch">Already have an account? <a href="login.php">Sign in</a></p>
        </section>
    </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>