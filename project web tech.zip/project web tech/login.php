<?php
require_once __DIR__ . '/includes/auth.php';
start_secure_session();

$errors = isset($_SESSION['login_errors']) ? $_SESSION['login_errors'] : array();
$oldEmail = isset($_SESSION['login_email']) ? $_SESSION['login_email'] : '';
unset($_SESSION['login_errors'], $_SESSION['login_email']);

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<main class="auth-page">
    <div class="container auth-container auth-container-login">
        <section class="auth-intro">
            <p class="eyebrow">Welcome back</p>
            <h1>Stay connected to what matters.</h1>
            <p>Sign in to continue building relationships, discovering opportunities and staying close to your community.</p>
            <div class="auth-quote">
                <span class="quote-mark" aria-hidden="true">“</span>
                <p>Your next idea, opportunity or conversation may be one connection away.</p>
            </div>
        </section>

        <section class="auth-card" aria-labelledby="login-title">
            <p class="eyebrow">Member access</p>
            <h2 id="login-title">Welcome back</h2>
            <p class="auth-card-subtitle">Sign in to your AlumniConnect account.</p>

            <?php if (!empty($errors)) : ?>
                <div class="form-alert form-alert-error" role="alert">
                    <?php foreach ($errors as $error) : ?>
                        <p><?php echo escape_html($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form action="actions/login.php" method="post" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?php echo escape_html(get_csrf_token()); ?>">
                <div class="form-field">
                    <label for="email">Email address</label>
                    <input type="email" id="email" name="email" maxlength="150" autocomplete="email" required value="<?php echo escape_html($oldEmail); ?>">
                </div>
                <div class="form-field">
                    <div class="label-row">
                        <label for="password">Password</label>
                    </div>
                    <input type="password" id="password" name="password" autocomplete="current-password" required>
                </div>
                <button class="button button-primary form-submit" type="submit">Sign in <span aria-hidden="true">→</span></button>
            </form>
            <p class="auth-switch">New to AlumniConnect? <a href="register.php">Create an account</a></p>
        </section>
    </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>